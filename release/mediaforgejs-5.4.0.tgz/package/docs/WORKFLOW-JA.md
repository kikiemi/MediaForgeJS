# Workflow API

新規の検査・再梱包・変換には`MediaWorkflow`を使用します。入力を一度開く`MediaJob`と、処理後に自動解放する単発メソッドを提供します。通常入口は組み込み形式・PCM/AAC-LC/MPEG Layer I/IIの復号・音声エンコーダー・`convert`処理を登録します。FFmpegは不要です。

## 検査と出力

```ts
import { MediaWorkflow } from 'mediaforgejs/workflow';

export async function remux(input: Blob) {
    const job = await new MediaWorkflow().open(input, {
        metadataPolicy: 'error',
    });
    try {
        const request = { operation: 'remux', format: 'mkv' } as const;
        const options = { maxBytes: 64 * 1024 * 1024 };
        const support = await job.check(request, options);
        if (!support.supported) throw new Error(support.reason);
        return await job.toBlob(request, options);
    } finally {
        job.close();
    }
}
```

`probe(request)`は同期の設定照会で、パケットを読みません。`await check(request, {maxBytes})`は実出力と同じwriter・変換処理・全パケット・finalizeを、出力を保存しないSinkに対して実行します。警告と進捗のコールバックは呼ばず、診断を`warnings`へ返します。破損パケット、出力時の設定、最終処理、指定したバイト上限まで検証します。

同じ不変入力・設定・実行環境で、同じ処理の成功／失敗を照合できます。将来のSourceの変更、書き込み先のI/O障害、中止、Sinkのseek能力、実プレイヤーの対応は保証しません。`check`・`write`・ストリームは既定の出力上限を設けません。`toBlob`は全出力を保持するため、既定で256 MiBに制限します。Blob出力と同じ条件を検証する場合は`check`にも同じ`maxBytes`を指定してください。

`check`の後に出力すれば処理は2回行われます。1回だけ変換する場合は、直接`write`／`toBlob`を呼んで例外を処理できます。通常の書き込みに全件の事前実行を追加していません。

| 操作 | 開いたJob | 単発のWorkflow |
| --- | --- | --- |
| 検査 | `job.inspect()` | `workflow.inspect(input, openOptions)` |
| 設定照会 | `job.probe(request)` | 入力を開いて`probe` |
| 全件検証 | `await job.check(request, {maxBytes})` | `workflow.check(input, request, {open, maxBytes})` |
| Sink出力 | `job.write(sink, request, {maxBytes})` | `workflow.write(input, sink, request, {open, maxBytes})` |
| Blob出力 | `job.toBlob(request, {maxBytes})` | `workflow.toBlob(input, request, {open, maxBytes})` |
| 逐次出力 | `job.toReadableStream(request, {highWaterMark, maxBytes})` | `workflow.toReadableStream(input, request, {open, highWaterMark, maxBytes})` |
| 分割MP4 | `job.segments(segmentOptions)` | `workflow.segments(input, segmentOptions, openOptions)` |

リクエストは`operation`と`format`を共通に持ちます。`onProgress`はすべて`{fraction, message?, packets?, packetBytes?}`の1引数で、`fraction`は0〜1です。秒・Hz・チャンネル数を明示し、`audio`のビットレートは`bitrateKbps`、`convert`の`audioBitrate`／`videoBitrate`はbits/sで指定します。

## ネイティブ音声変換

```ts
const workflow = new MediaWorkflow();
const output = await workflow.toBlob(input, {
    operation: 'audio',
    format: 'mp3',
    sampleRate: 48000,
    channels: 2,
    bitrateKbps: 192,
    start: 1,
    end: 8,
    onProgress: ({ fraction }) => console.log(fraction),
});
```

| 機能 | 条件 |
| --- | --- |
| PCM入力 | 対応WAVE/AIFF/AU/CAF/AVI/MKV等。標準mono/stereo配置、連続・未編集タイムライン、1パケット64 MiB以下 |
| AAC-LC入力 | 組み込みJavaScript復号。入力のpriming／末尾trimを反映 |
| MPEG Layer I/II入力 | 組み込みJavaScript復号。対応する連続フレーム |
| MP3入力 | ホストの`AudioDecoder`または利用側が登録するデコーダーが必要 |
| 出力 | WAV/AIFF/AU/CAF、AAC-LC（ADTS）、MP2、MP3、FLAC |
| 音声選択 | `trackId`を明示、または唯一の音声、または唯一の`default:true`音声 |
| 切り出し | 入力のtrim後の時刻に`start`以上・`end`未満を適用 |

PCM/FLACの再符号化出力は16 bitです。浮動小数や16 bitを超えるPCM入力には`allowPrecisionLoss:true`が必要です。正確なビット列を保つコンテナ変換は`operation:'remux'`を使用します。音声出力に持ち込めないタイトル・言語・dispositionは警告し、`metadataPolicy:'error'`では拒否します。

## 映像と音声の変換

```ts
const workflow = new MediaWorkflow();
const output = await workflow.toBlob(input, {
    operation: 'convert',
    format: 'mkv',
    audioSampleRate: 24000,
    audioChannels: 1,
    audioBitrate: 48000,
});
```

変換不要なトラックはコピーします。コピーだけなら複数映像・複数音声を保持し、WebCodecsも不要です。実際の再符号化は映像最大1本・音声最大1本を扱います。それ以上ある場合は`trackIds`で明示的に選んでください。対応PCM・AAC-LCからAAC-LCへの変換はJavaScriptで行え、映像コピーと同時に出力できます。M4Aの再符号化もこの`convert`経路で扱います。MPEG音声の組み込み復号は`operation:'audio'`で利用します。

映像の復号・再符号化はホストのWebCodecsに、サイズ変更はOffscreenCanvasにも依存します。通常入口はこの処理を登録済みです。再符号化もSourceの必要な範囲から読み、入力全体のBlobへのコピーを行いません。圧縮索引を共有し、全サンプルを重複オブジェクト化しません。`maxInputBytes`は任意の入力上限で、未指定ならファイルサイズによる上限は設けません。ProResのMOV出力にはstandardモードを使います。`patchAt`を持たないSinkへのstandard MP4/MOV出力はwriter内に圧縮データを保持するため、大きなファイルにはpatch可能なSinkを使用してください。全形式の逐次入力や全コーデックの自前復号を提供するものではありません。

選択構成は`createNativeVideoTransform({formats, maxInputBytes})`を`workflow/transcode-core`から`workflow/core`の`transform`へ渡します。通常入口でも独自の`transform`で差し替えられます。WebCodecsの実機対応は、利用するブラウザーで確認してください。

## 必要な部品だけ登録する

```ts
import { MediaWorkflow } from 'mediaforgejs/workflow/core';
import { audio } from 'mediaforgejs/engine/formats/audio';
import { pcmAudio } from 'mediaforgejs/workflow/audio-pcm';

export const workflow = new MediaWorkflow({ formats: [audio], audio: pcmAudio });
```

`workflow/core`は空の構成から始まります。圧縮音声の復号は`workflow/audio-decode`の`nativeAudioDecoder`を追加できます。出力エンコーダーは`workflow/audio-core`の`createWorkflowAudio({aac, mp2, mp3, flac})`へ必要なstreaming encoderだけを登録できます。既定一式は`workflow/audio`の`nativeAudio`です。Converter/Pipelineの選択式入口も維持しています。

## バッチと所有権

```ts
const results = await workflow.batch([
    { input: first, request: { operation: 'remux', format: 'mkv' } },
    { input: second, request: { operation: 'audio', format: 'wav' } },
], { concurrency: 2, signal });
```

結果は入力順の`PromiseSettledResult<Blob>[]`です。既定並列数は2で、1件の失敗だけでは他を停止しません。中止は進行中の処理へ伝え、未開始項目の入力を開きません。

Jobは同時に1操作だけ受け付けます。`job.close()`は処理を中止し内部資源を解放しますが、借用したSourceは閉じません。単発操作・終了したstream／segmentsは内部Jobを解放します。受理した出力は成功時にSinkを閉じ、実行中の失敗では`abort()`を要求します。出力先には入力と別のファイルを指定してください。

`validation`は構造検証、`metadataPolicy`は任意メタデータの保持を制御します。既定は`compatible`と警告での続行です。`strict`をメタデータ損失の拒否へ読み替えていません。

## 共通出力オプション

単発の`check`・`toBlob`・`write`は共通の`{open, maxBytes}`を受け取ります。

```ts
const options = {
    open: { signal, cacheBytes: 0 },
    maxBytes: 512 * 1024 * 1024,
};
const checked = await workflow.check(input, request, options);
if (!checked.supported) throw new Error(checked.reason);
await workflow.write(input, sink, request, options);
```

既に開いたJobでは`job.write(sink, request, {maxBytes})`とします。従来の`workflow.write(..., {signal, maxSamples, ...})`も互換のため利用できます。新規コードでは`open`へ入力オプションをまとめます。`toBlob`だけが既定で256 MiBに制限します。`check`/`write`/ストリームは上限未指定ならこの制限を適用しません。同じ上限条件で検証する場合は`maxBytes`を明示してください。

TSの`remux`はAVC/HEVC映像1本と複数音声を保持し、番組表・言語・音声ごとの設定と時刻を書きます。ProResはMOVとMKV間でコピーできます。AVI H.264では格納形式に応じてSPS/PPSを復元し、パケット読込時にNAL表現を正規化します。いずれもFFmpegを起動しません。

## ProResと映像コーデックの追加

`mediaforgejs/workflow/video`の`createVideoTransform({formats, codecs})`を`transform`へ渡すと、インスタンス単位で映像コーデックを追加できます。既存のWebCodecs経路はフォールバックとして利用します。ProRes拡張との組み合わせ、色深度を減らす際の`allowPrecisionLoss`、対応外の操作は[ProRes API](PRORES-JA.md)を参照してください。

## 出力先とキャンセル

入力のopenや変換計画で拒否された場合、呼び出し元のSinkには書き込み・終了通知を送りません。書き出し開始後の失敗は任意の`abort(reason)`へ通知します。ローカルファイルのSinkを先に開く場合は、下記のように呼び出し元でも失敗を後始末します。

```ts
const sink = await FileSink.open('output.ts');
try {
    await workflow.write(source, sink, { operation: 'remux', format: 'ts' });
} catch (error) {
    await sink.abort(error);
    throw error;
}
```

`FileSink.abort`は複数回呼べます。独自Sinkの所有権・終了処理はその実装に合わせて扱ってください。

入力Sourceは借用します。JobやWorkflowの終了だけでは呼び出し元が開いたFileSourceを閉じないため、利用側の`finally`で閉じます。Node/Denoの`FileSource.open(..., {signal})`は、中止を確認してからファイルを開き、メタデータ取得待ちも中止できます。
