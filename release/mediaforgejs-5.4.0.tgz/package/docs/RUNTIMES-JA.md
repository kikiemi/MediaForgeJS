# 実行環境と入出力

共通のSource/Sink・パケット処理・字幕・メタデータはDOM不要です。ファイルAPIは`mediaforgejs/runtime/node`、`mediaforgejs/runtime/bun`、`mediaforgejs/runtime/deno`から読み込みます。ブラウザー向けエントリーにファイルシステム依存は入りません。

```ts
import { HttpSource, MediaEngine } from 'mediaforgejs';

export async function inspectRemote(url: string, signal?: AbortSignal): Promise<void> {
    const source = await HttpSource.open(url, { signal, requireValidator: true });
    try {
        const file = await new MediaEngine().open(source, { signal });
        try { console.log(file.tracks); }
        finally { file.close(); }
    } finally { await source.close(); }
}
```

`HttpSource`はRangeへの206応答、Content-Range、長さ、リソースの同一性を検証します。強いETagがあればIf-Matchを使用し、観測できたETag・Last-Modified・転送先URL・サイズの変化は拒否します。強いETagがない場合は標準で警告し、`requireValidator:true`で拒否できます。Last-Modifiedとサイズだけではすべての内容変更を検知できません。CORSではContent-Range・ETag・Last-Modifiedの公開が必要です。

Range非対応サーバーは標準では拒否します。`fallback:'buffer'`と明示した`maxBytes`で、open時のみ全体保持へ切り替えられます。途中で200応答へ切り替えて異なるデータを混ぜません。`maxResponseBytes`は標準8 MiBの1応答上限です。大きなreadは分割して取得しますが、戻り値と同時read全体のメモリーをこの値で制限するものではありません。

```ts
import { StreamSource } from 'mediaforgejs';

export async function retain(response: Response): Promise<StreamSource> {
    if (!response.body) throw new Error('Response body is missing');
    return StreamSource.from(response.body, { retention: 'memory', maxBytes: 64 * 1024 * 1024 });
}
```

`StreamSource.from`はEOFまで消費してから返る、明示的上限付きのランダムアクセス入力です。入力全体の保持量が入力長に依存します。無限ストリームを定数メモリーで索引化するAPIではありません。失敗・中止時はreaderをcancel、iteratorをreturnします。細かい入力を64 KiBページへまとめ、入力chunkごとの配列は保持しません。`maxEmptyChunks`は連続する空chunkの上限で標準1024、0なら最初の空chunkを拒否します。データが来ると連続数をリセットします。`maxBytes`は入力payloadの上限で、返却コピーや上流のメモリーまで制限しません。

fMP4をEOF前から処理する場合は`readCmafSegments(response.body, options)`を使用できます。初期化・メディア断片を逐次返し、任意長の配信全体を保持しません。対応するfragment構造と上限はSTREAMING-JA.mdを参照してください。

`FileSource.open()`はファイルを所有し、`from(handle)`は標準で借用します。`closeHandle:true`で所有権を移します。所有するhandleは初期化中のstat・形式確認・truncate失敗時にも解放します。読み取り中にファイルの内容を変更しないでください。

`FileSink.open()`は出力を作成・切り詰めます。`from(handle)`も内容を切り詰めます。Nodeのhandleはappendなしで開いてください。`write/patchAt`の後は`drain()`でバックプレッシャーを待ち、最後に`close()`します。失敗時は`abort(error)`。abortは既に書いたファイルのロールバックではありません。元ファイルを原子的に置き換える場合は、別の一時ファイルへ成功するまで書き、アプリ側でrenameしてください。`highWaterMark`は協調的なキューのしきい値であり、単一writeのサイズ上限ではありません。

`nodeReadableSource`はNodeのReadableを制限付きで全体保持します。`await nodeWritableSink(writable)`はNode Writableを既存Sinkへ適合させます。後者はseekできないため、seek必須の出力では使えません。Denoのseek/readは直列化され、close/abort後に待機中のI/Oを開始しません。借用handleのカーソルを他の利用者と共有しない契約です。

| 環境 | この版の確認範囲 |
| --- | --- |
| Node 24.19.0 / Linux | 実ファイル、部分I/O、ストリーム、ローカルHTTP、取消、FFmpeg 6.1.1の実行検証 |
| Chromium | ブラウザーバンドルと既存変換経路の実行検証 |
| Bun | Node互換アダプター。Bun本体が環境にないため実機未検証 |
| Deno | ネイティブAPI向けアダプターの契約検証。Deno本体での実行・権限挙動は未検証 |

画像のブラウザー復号・描画、DOMフォールバック、AudioContext、WebCodecs、Workerの有無は実行環境に依存します。Node用ファイルAPIだけでネイティブな動画エンコーダーが追加されることはありません。

参照: [Node fs](https://nodejs.org/api/fs.html)、[Node streams](https://nodejs.org/api/stream.html)、[Bun Node互換](https://bun.com/docs/runtime/nodejs-compat)、[Deno filesystem](https://docs.deno.com/api/deno/file-system/)。

## 導入済みFFmpegを使う追加経路

`mediaforgejs/runtime/ffmpeg`はNode/Bun向けの明示的な追加モジュールです。FFmpeg/ffprobeは利用側で導入し、PATHまたは`new FFmpegBackend({ ffmpegPath, ffprobePath })`で指定します。バイナリの同梱・自動取得はありません。ブラウザー本体へプロセス実行の依存は入りません。

```ts
import { FFmpegBackend } from 'mediaforgejs/runtime/ffmpeg';

export async function transcode(input: string, output: string): Promise<number> {
    const backend = new FFmpegBackend();
    const capabilities = await backend.capabilities();
    if (!capabilities.encoders.includes('libx264') || !capabilities.encoders.includes('aac')) {
        throw new Error('H.264/AAC encoder is unavailable');
    }
    const info = await backend.probe(input);
    const streams = info.streams.filter(stream => stream.codec_type === 'video' || stream.codec_type === 'audio')
        .map(stream => stream.index);
    const result = await backend.convert(input, output, {
        format: 'mp4', streams,
        videoCodec: 'libx264', audioCodec: 'aac',
        videoBitrate: 4_000_000, audioBitrate: 192_000,
        maxInputBytes: 2 * 1024 * 1024 * 1024,
        maxOutputBytes: 2 * 1024 * 1024 * 1024,
        timeoutMs: 300_000,
    });
    return result.bytesWritten;
}
```

| API | 契約 |
| --- | --- |
| `capabilities(options?)` | 実際に指定したFFmpegのversion・demuxers・muxers・decoders・encodersを返す |
| `probe(input, options?)` | ffprobeのformat/streamsを取得。プロパティ名は`codec_name`、`sample_rate`などのsnake_caseを維持 |
| `convert(input, output, options)` | 必須の`format`で単一出力へ書く。指定したコーデックだけを再符号化し、未指定の種類はコピー |
| `remux(input, output, options)` | 再符号化せずに選択ストリームをコピー |
| `exportDirectory(input, destination, options)` | HLS/DASHの完了したVODを新しいディレクトリーへ出力 |

入力はローカルファイル名またはSource、出力はローカルファイル名またはSinkです。既定は全ストリームを選択し、必要なら`streams`へ入力の0始まりのstream indexを指定します。出力コンテナが選択した種類・コーデックを格納できなければ失敗します。メタデータと章もFFmpegへ保持を要求しますが、コンテナ間の完全な保存を保証しません。任意のコマンド引数を渡すAPIではありません。

Sourceは上限付きの一時ファイルへ順に書いてから解析・変換します。末尾にmoovを持つMP4など、seekを必要とする入力にも対応するためです。Source全体のディスク保持を伴い、EOF前から入力する低遅延APIではありません。入力は単独で完結するファイルを対象とし、別のファイルを参照するプレイリストや素材セットをSourceから再構成しません。

ファイル出力は同じファイルシステム上の一時ファイルで完了を確認してから公開します。`overwrite`は既定false。入力と同じファイルへの書き出しは拒否します。Sinkは標準出力からバックプレッシャー付きで渡し、seek不要の対応muxerに限定します。`format:'mp4'`のSink出力には`fragmentedMp4:true`が必要です。借用Source/Sinkのclose/abortは呼び出さないため、利用側で完了・中止を処理してください。失敗時に既に受け取ったSinkのバイトは取り消せません。

既定値は入力・出力それぞれ1 GiB、probe JSON 4 MiB、1操作の制限時間120秒です。`maxInputBytes`、`maxOutputBytes`、`maxProbeBytes`、`timeoutMs`で変更できます。Sink出力の上限はwrite前に確認します。seek可能なファイル出力の上限は完成後のサイズ検証であり、一時ディスク使用量の厳密な上限ではありません。中止・時間超過・失敗時は子プロセスの終了を待って一時ファイルを片付けます。終了要求後500 msで強制終了へ進み、POSIXでは専用のプロセスグループ、Windowsでは直接の子プロセスを対象にします。

HLS/DASH・連番画像・segment/teeなど、複数リソースを生成するmuxerはこの単一出力APIでは拒否します。`capabilities()`の一覧は導入済みFFmpegの能力であり、このAPIの対応範囲や、個々のプロファイル・組合せの成功保証ではありません。Deno用プロセスバックエンドは含みません。

この版ではNode 24.19.0 / LinuxとFFmpeg 6.1.1で検証しました。従来のMP4/WebM等に加え、MXF、CAF、ASF/WMA、MPEG-PS、TGAの入力・変換を確認し、CAFの24bit PCMも照合しています。導入環境の能力一覧はdemuxer名374（別名を含む）・muxer189・decoder534・encoder223でした。これらは今回の導入バイナリの一覧で、全組合せを検証した件数ではありません。Bun本体・Windowsでのこのバックエンドの実行は未検証です。

参照: [FFmpegのstreamcopy・stream selection](https://ffmpeg.org/ffmpeg.html)、[ffprobe](https://ffmpeg.org/ffprobe.html)。

## HLS/DASHのVOD書き出し

```ts
import { FFmpegBackend } from 'mediaforgejs/runtime/ffmpeg';

export async function exportHls(input: string, destination: string, signal?: AbortSignal) {
    return new FFmpegBackend().exportDirectory(input, destination, {
        format: 'hls', hlsSegmentType: 'fmp4', segmentDuration: 6,
        videoCodec: 'libx264', audioCodec: 'aac',
        maxFiles: 10000, maxOutputBytes: 2 * 1024 * 1024 * 1024,
        timeoutMs: 300000, signal,
    });
}
```

`format:'hls'`はTS（既定）またはfMP4、`format:'dash'`はfMP4です。マニフェスト名は`index.m3u8`または`manifest.mpd`で、参照ファイル名はライブラリが生成します。`segmentDuration`は既定6秒、0.1〜3600秒の目標長です。キーフレーム間隔・入力時刻・コーデックによって実際の長さは変わり、最大長や各断片の独立再生を保証しません。

出力先は存在しないディレクトリーを指定します。作業開始時に空ディレクトリーを排他的に予約するため、完了前でもその空の名前は見えます。兄弟の一時ディレクトリーで生成・検査を終えてから予約先へ移します。Windowsでは空の予約ディレクトリーを除去してから最終renameを行うため、その直前に予約名が一時的になくなります。既存ディレクトリーを上書きする設定はありません。処理中に利用側から出力先・その親を変更しないでください。失敗時の片付けはライブラリが所有する予約と一時出力に限定します。

`maxFiles`はマニフェストと初期化ファイルを含め、既定10000、最大100000です。マニフェスト自体には8 MiBの上限があります。`maxOutputBytes`は生成した全ファイルの合計上限です。これらは完成後の公開前検査で、一時ディスクの使用量や生成途中のファイル数に対する厳密な制限ではありません。戻り値は絶対`directory`・`manifestPath`、相対名とバイト数の`files`、合計`bytesWritten`です。

入力は既存の単独ファイル／Source契約を使います。ライブ配信への継続出力、任意のファイル名テンプレート、ABR ladder、暗号化、完全なCMAFプロファイル適合はこのAPIに含みません。この経路は映像・音声のVODを対象にし、HLS字幕のsidecar生成などは対象外です。必要なら`streams`で映像・音声の入力indexを選びます。選択トラックと出力の互換性は導入済みFFmpegに依存します。HLS/DASHの各出力は別のディレクトリーへ移動してからも参照できる相対ファイル構成です。

参照: [FFmpeg HLS muxer](https://ffmpeg.org/ffmpeg-formats.html#hls)、[FFmpeg DASH muxer](https://ffmpeg.org/ffmpeg-formats.html#dash-2)。

この版の独立検証では、FFmpeg 6.1.1による一部のDASH MPD読出しで末尾フレームが少なくなる条件を確認しました。書き出した7リソースは同じ引数のFFmpeg直接実行と全バイトが一致し、マニフェストが参照する初期化データと断片には完全なトラックが残っています。MPD経由の外部プレーヤーの復号結果まで同一になるという保証はせず、再生環境側でも確認してください。
