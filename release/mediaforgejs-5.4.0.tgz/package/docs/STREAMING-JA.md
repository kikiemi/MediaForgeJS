# HLS・DASH・分割MP4・暗号化再生

`HlsClient`はプレイリストと完成済みセグメントまたは公開済みPARTを取得し、`CmafWriter`は符号化済みサンプルを初期化セグメントとMP4フラグメントにまとめます。映像・音声の再生、再符号化、配信サーバーの作成は行いません。

## 静的DASHのセグメント計画

`parseDashManifest`は静的MPDを読み、Period・AdaptationSet・Representationを保持します。映像・音声・字幕の選択と取得は利用側が行います。`iterateDashSegments`は選択したRepresentationからURL・byte range・整数時刻を必要に応じて返します。

```ts
import { parseDashManifest, iterateDashSegments } from 'mediaforgejs';

export function planDash(xml: string, manifestUrl: string): void {
    const manifest = parseDashManifest(xml, {
        baseUrl: manifestUrl,
        maxBytes: 8 * 1024 * 1024,
        onWarning: warning => console.warn(warning.code, warning.message),
    });
    for (const period of manifest.periods) {
        for (const group of period.adaptationSets) {
            const track = group.representations[0];
            if (!track) continue;
            console.log(track.contentType, track.codecs, track.initialization);
            for (const segment of iterateDashSegments(track, {
                start: 10, end: 20, maxSegments: 1000,
            })) {
                console.log(segment.url, segment.byteRange, segment.number,
                    segment.time, segment.duration, segment.timescale);
            }
        }
    }
}
```

`baseUrl`にはMPDの絶対HTTP(S) URLを指定します。各階層のBaseURLとSegmentTemplate/SegmentListを継承し、初期化リソースは`initialization`に分離します。`$Number$`、`$Time$`、`$RepresentationID$`、`$Bandwidth$`、`$$`、数値の`%0Nd`指定を扱います。SegmentTimelineの`r=-1`は次の明示時刻または有限のPeriod終端で解決し、繰り返しを配列へ全件展開しません。

検索の`start/end`はPeriod開始を含む全体の表示秒で、`[start,end)`と重なるセグメントを選びます。Periodの外だけにある参照は返しません。`time/duration`と`number`は`bigint`、`time`はPTOを引く前のメディアtickです。表示秒は`Period.start + (time − presentationTimeOffset) / timescale`です。整数tickと範囲判定を正確に保ち、表示用の`presentationTime/presentationDuration`だけをnumberへ変換します。境界でセグメントのバイトやdurationを切り詰める編集APIではありません。

標準制限はMPD 8 MiB、XMLノード200000・深さ64、Representation 1024個、1 Representationあたり参照100万個です。`maxPlanEntries`は全Representationを合算した正規化済みtimeline区間・SegmentListリソース数の上限で標準200000です。継承による増幅にも適用します。URL/テンプレートは個別65536文字、計画へ保持する合計16777216文字を固定上限とし、継承後の巨大なURL列も拒否します。iteratorの`maxSegments`超過は最初の出力前に失敗します。返却モデルは変更不能で、iteratorには同じパーサーが返したRepresentationをそのまま渡します。複製・JSON復元したモデルからの列挙には対応しません。

dynamic MPD、暗号化ContentProtection、xlink、xml:base、複数BaseURLの選択、依存Representationなど未対応の参照方式は明示的に拒否します。URL計画だけで、HTTP認証、range取得、ABR、再生時計やDRMの実装を追加するものではありません。

### 単一ファイルDASHとsidx

SegmentListの`SegmentURL@index/indexRange`は補助索引として`segment.index`へ保持します。`mediaRange`はそのままセグメントの範囲です。FFmpegのsingle-file MPDも元の参照を変更せずに計画できます。

SegmentBaseには非同期の`resolveDashManifest`を使用します。次の例では指定された索引範囲だけを取得し、解決済みのRepresentationを従来と同じiteratorへ渡します。

```ts
import { resolveDashManifest, iterateDashSegments, HttpSource } from 'mediaforgejs';

export async function planIndexedDash(xml: string, manifestUrl: string, signal?: AbortSignal): Promise<void> {
    const manifest = await resolveDashManifest(xml, {
        baseUrl: manifestUrl, signal,
        maxIndexBytes: 8 * 1024 * 1024,
        maxIndexRequests: 256,
        async readIndex(resource, signal) {
            const source = await HttpSource.open(resource.url, { signal, requireValidator: true });
            try { return await source.read(resource.byteRange.offset, resource.byteRange.length); }
            finally { await source.close(); }
        },
    });
    for (const period of manifest.periods) for (const group of period.adaptationSets) {
        for (const representation of group.representations) {
            console.log(representation.segmentCount, representation.initialization);
            for (const segment of iterateDashSegments(representation)) {
                console.log(segment.url, segment.byteRange, segment.presentationTime);
            }
        }
    }
}
```

ライブラリはHTTP取得を暗黙に開始せず、`readIndex(resource, signal)`を逐次呼びます。各リクエストのbyteRangeは必須で、戻り値はその範囲と正確に同じ長さのUint8Arrayです。初期化・メディア自体の取得や、複数取得にまたがるリソース同一性の維持は利用側が担当します。同期の`parseDashManifest`は未解決SegmentBaseを引き続き拒否します。

`sidx`のversion0/1・64bit box長・earliest presentation time・first offset・各参照の時刻とサイズ・SAPを解析します。`indexRangeExact`がfalseなら指定範囲のboxを走査して1個のsidxを探します。この場合も指定範囲は完全なbox列である必要があり、box途中からの探索はしません。絶対バイト位置はsidx boxの終端からfirst offsetを加算します。解決後は実際の`segmentCount:bigint`を持つ変更不能なリスト計画になり、`segmentInfo.sourceType === 'segment-base'`、`segmentInfo.index`、`segmentInfo.sidx`で由来と索引を確認できます。

MPDのPTOとsidxのtimescaleが異なる場合は正確な整数換算を行います。整数tickで表現できないPTO、階層sidx、複数sidx、空または長さ0の参照、JavaScriptで正確に表現できないbyte rangeは拒否します。事前にMPD全体と宣言された取得量を検証し、取得途中の参照数増幅にも上限を適用します。

既定の合計上限は`maxIndexBytes` 8 MiB、`maxIndexReferences` 200000、`maxIndexRequests` 256です。設定できる最大値は順に64 MiB・100万・4096。個々のindex rangeは32 bytes〜1 MiB、1範囲の走査は4096 boxまでです。既存の`maxSegments`・`maxPlanEntries`・URL保持上限も適用します。

`parseSidx(bytes, { offset: 0n })`は単独の完全なsidx boxを読む低水準APIです。入力を保持せず、byte offset・time・durationをbigintで返します。`maxBytes`の既定・最大は1 MiB、`maxReferences`の既定・最大は65535です。低水準パーサーは階層参照を`referenceType:1`として識別しますが、次の索引の取得・展開はしません。

参照: [DASH-IF timing model](https://dashif.org/Guidelines-TimingModel/)。

## EOFを待たない分割MP4入力

`readCmafSegments`はWebのReadableStreamまたはAsyncIterableの任意のchunk境界を処理し、初期化セグメントと完成したメディア断片を返します。次の例は受信中のfMP4から、断片ごとに圧縮パケットを取り出します。

```ts
import { readCmafSegments, MediaEngine, BufferSource, ConcatSource } from 'mediaforgejs';

export async function inspectFragmentStream(
    input: ReadableStream<Uint8Array> | AsyncIterable<Uint8Array>,
    signal: AbortSignal,
): Promise<void> {
    const segments = readCmafSegments(input, {
        signal,
        validation: 'compatible',
        maxBoxBytes: 32 * 1024 * 1024,
        maxSegmentBytes: 64 * 1024 * 1024,
        onWarning: warning => console.warn(warning.code, warning.message),
    });
    const engine = new MediaEngine();
    let initialization: Uint8Array | undefined;
    for await (const segment of segments) {
        if (segment.kind === 'init') {
            initialization = segment.data;
            continue;
        }
        if (!initialization) throw new Error('初期化セグメントがありません');
        const file = await engine.open(new ConcatSource([
            new BufferSource(initialization), new BufferSource(segment.data),
        ]), { format: 'mp4', signal });
        try {
            for await (const packet of file.packets({ signal })) {
                console.log(packet.trackId, packet.timestamp, packet.data.byteLength);
            }
        } finally { file.close(); }
    }
}
```

`iterateMp4Boxes(input, options)`は同じ入力からトップレベルboxを返す低水準APIです。`offset`、実際の`size`、`headerSize`、ヘッダー込みの独立した`data`を持ちます。64bit size、UUID、EOFまで延びるsize=0を扱います。size=0のboxだけは終端確定にEOFが必要です。

セグメント読み出しはftyp+moovの初期化、moof相対アドレスのmoof+1個のmdatを対象にし、宣言トラック・trunのデータ範囲を検証します。emsg・prft・stypなどのprefixを保持します。progressive MP4、絶対データオフセット、1断片の複数mdat構成は拒否します。MP4のすべてのbox配置に対応するデマルチプレクサーではありません。

標準はstrictです。compatibleを明示した場合、完全な初期化が成立した後の不完全な末尾は警告して捨て、先に返した完成断片を利用できます。必須初期化や不正なサンプル範囲を推測して通すことはありません。診断はiteratorの`diagnostics`と`onWarning`から確認できます。

既定の上限は1 box 64 MiB、1 segment 128 MiB、入力chunk 16 MiB、box数100000、連続空chunk 1024です。上限は各対象のサイズで、上流や返却結果の保持を含むプロセス全体のメモリー制限ではありません。利用側の`next()`に応じて読み進め、配信全体を保持しません。中止と`return()`は保留中の`next()`を解除し、readerのcancel・lock解放またはiteratorのreturnを要求します。

## HLSの選択と取得

マスタープレイリストでは、利用側がvariantを選んで再度`load()`します。音声・字幕の代替renditionは`renditions`に入り、`groupId`をvariantの`audio`・`subtitles`と照合できます。3.12.0の`getHlsRenditions`／`selectHlsRendition`でgroup、言語、既定／強制指定をもとに選べます。[使用例](3.12.0-FEATURES-JA.md#hlsの音声字幕選択)を参照してください。別URIのrenditionは別の`HlsClient`で取得します。異なるrenditionのmedia sequenceが同じでも、同一時刻とは限りません。

次の例はfMP4 HLS専用です。最新の初期化データを保持し、**セグメントごとに**`ConcatSource`で結合してパケットを読みます。配信全体の連結・編集・同期は行いません。呼び出し側がパケット時刻と`discontinuitySequence`を保持し、不連続時のデコーダー再初期化などを管理します。

```ts
import { HlsClient, BufferSource, ConcatSource, MediaEngine } from 'mediaforgejs';

export async function inspectHls(url: string, signal: AbortSignal): Promise<void> {
    const client = new HlsClient({
        signal,
        maxPlaylistBytes: 2 * 1024 * 1024,
        maxSegmentBytes: 32 * 1024 * 1024,
        onWarning: warning => console.warn(warning.code, warning.message),
    });
    const engine = new MediaEngine();
    let initialization: Uint8Array | undefined;
    try {
        let playlist = await client.load(url);
        if (playlist.type === 'master') {
            const variant = playlist.variants.find(item => !item.iframe);
            if (!variant) throw new Error('通常のvariantがありません');
            playlist = await client.load(variant.uri);
        }
        if (playlist.type !== 'media') throw new Error('media playlistが必要です');
        for await (const item of client.segments({ live: !playlist.endList })) {
            if (item.initData) initialization = item.initData;
            if (!initialization) throw new Error('この例にはEXT-X-MAPが必要です');
            const source = new ConcatSource([
                new BufferSource(initialization),
                new BufferSource(item.data),
            ]);
            const file = await engine.open(source, { format: 'mp4', signal });
            try {
                for await (const packet of file.packets({ signal })) {
                    console.log(item.segment.sequence, item.segment.discontinuitySequence,
                        packet.trackId, packet.timestamp, packet.duration);
                }
            } finally {
                file.close();
            }
        }
    } finally {
        client.close();
    }
}
```

`AbortController.signal`を渡し、停止時に`abort()`します。`client.close()`も保留中の取得・更新待ちを中止し、以後そのclientは再利用できません。`for await`から`break`するとiteratorを終了し、直接取得したiteratorの`return()`は保留中の`next()`も中止します。中止時の拒否は呼び出し側で処理してください。

取得は`next()`に応じて順番に進み、先読みしません。初期化データはMAPの変更時とdiscontinuityの変更時に返されます。`segments()`は初期状態では現在のプレイリストだけを処理し、`{ live: true }`で更新を継続します。`startSequence`で開始位置を指定できます。同一clientで並行する取得・`load()`・`refresh()`は拒否します。

ライブ更新ではsequenceの後退、既存セグメントのURI・時間・鍵・MAPの変更などを拒否します。取得位置がライブ窓から外れた場合や`EXT-X-GAP`は、既定の`validation: 'compatible'`で警告して先へ進み、`'strict'`では失敗します。警告は`client.diagnostics`でも参照できます。

## PARTとdelta更新

```ts
import { HlsClient } from 'mediaforgejs';

export async function receiveParts(url: string, signal: AbortSignal): Promise<void> {
    const client = new HlsClient({ signal, requestTimeoutMs: 30000, maxPlaylistEntries: 100000 });
    try {
        const playlist = await client.load(url);
        if (playlist.type !== 'media') throw new Error('variantのmedia playlistを指定してください');
        for await (const unit of client.parts({ live: true, maxRefreshes: 100, maxIdleRefreshes: 10 })) {
            if (unit.type === 'part') console.log(unit.sequence, unit.partIndex, unit.data.byteLength);
            else console.log(unit.segment.sequence, unit.data.byteLength);
        }
    } finally { client.close(); }
}
```

`parts()`は公開済みPARTを取得し、PARTがなければ完成セグメントを返します。既定では非暗号化とAES-128 identityに対応し、`data`と`initData`は復号済みです。3.11.0では暗号ハンドラーも指定でき、CDMへ暗号文を渡す場合は`unit.encryption`を付けます。[SAMPLE-AES・DRMの対応範囲](PROTECTED-HLS-JA.md)を参照してください。`initData`、MAP、byte range、不連続情報を保持します。一部PARTを返した親セグメント全体は重複取得しません。親が完成セグメントとして残る一方で未取得PARTが消えた場合は`HLS_PART_WINDOW`、親ごとライブ窓から消えた場合は`HLS_LIVE_WINDOW`を通知します。欠けたサンプルの自動補完は行いません。

`parts()`の既定は現在のスナップショットのみです。`live:true`でポーリングし、既定で10回の進展しない更新を上限にします。`maxRefreshes`は合計更新回数を制限します。同時到達時は合計上限による正常終了を優先します。`segments()`にも更新上限を渡せますが、既定のidle上限は追加していません。

`refresh()`は保持する直前のmedia playlistから`EXT-X-SKIP`を復元します。単体パーサーでは`parseHlsPlaylist(text,{previousPlaylist})`を指定します。clientの取得・更新、または`previousPlaylist`を指定した復元では、必要な履歴の欠落や`RECENTLY-REMOVED-DATERANGES`を伴うdate-range deltaを拒否し、成功時は完全なプレイリストを返します。履歴を指定しない単体解析は、互換性のため未解決の`skippedSegments`を含むモデルも返せます。blocking reloadとPRELOADの投機取得は実装していません。

## プレイリストの読み書き

```ts
import { parseHlsPlaylist, serializeHlsPlaylist } from 'mediaforgejs';

export function normalizePlaylist(text: string, baseUrl: string): string {
    const playlist = parseHlsPlaylist(text, { baseUrl, validation: 'compatible' });
    console.log(playlist.diagnostics);
    return serializeHlsPlaylist(playlist);
}
```

`baseUrl`を指定すると参照URIを絶対URIへ解決します。マスター、代替rendition、EXTINF、MAP、KEY、byterange、sequence、不連続、program date、date rangeなどを扱います。省略されたbyterange offsetは同一リソースの直前の範囲からだけ導出します。文字列出力は対応するモデルから再構成し、未知の拡張タグ・コメント・元の整形は保持しません。出力versionは最低7、扱う低遅延タグがあれば最低9です。

## CmafWriterからSinkへ書く

次の関数は、48 kHz・2チャンネル・1フレーム1024サンプルの**符号化済みAAC-LC raw access unit**を受け取り、1つの初期化ファイルと1つのメディアファイル、およびVODプレイリストを作ります。呼び出し側が2つの`WritableStream`をそれぞれ`init.mp4`・`media-0.m4s`として保存・配信し、返された文字列を同じディレクトリの`.m3u8`に保存します。

```ts
import { CmafWriter, WritableStreamSink, serializeHlsPlaylist } from 'mediaforgejs';

export async function writeAacSegment(
    frames: readonly Uint8Array[],
    initOutput: WritableStream<Uint8Array>,
    mediaOutput: WritableStream<Uint8Array>,
    signal?: AbortSignal,
): Promise<string> {
    if (frames.length === 0) throw new Error('AACフレームが必要です');
    const writer = new CmafWriter({
        tracks: [{
            id: 1, type: 'audio', codec: 'mp4a.40.2', timescale: 48000,
            sampleRate: 48000, channelCount: 2,
            codecConfig: Uint8Array.of(0x11, 0x90),
        }],
        maxBufferedBytes: 16 * 1024 * 1024,
        maxBufferedSamples: 100000,
    });
    let dts = 0n;
    for (const data of frames) {
        signal?.throwIfAborted();
        writer.addSample({ trackId: 1, data, decodeTimestamp: dts,
            duration: 1024, isKeyframe: true });
        dts += 1024n;
    }
    const sinks: WritableStreamSink[] = [];
    try {
        const initSink = new WritableStreamSink(initOutput);
        sinks.push(initSink);
        const mediaSink = new WritableStreamSink(mediaOutput);
        sinks.push(mediaSink);
        await writer.writeInitSegment(initSink, signal);
        await initSink.close();
        const segment = await writer.flushTo(mediaSink, {}, signal);
        await mediaSink.close();
        const track = segment.tracks[0]!;
        const duration = Number(track.duration) / track.timescale;
        return serializeHlsPlaylist({
            type: 'media', targetDuration: Math.ceil(duration),
            mediaSequence: 0, discontinuitySequence: 0,
            independentSegments: segment.independent, endList: true, playlistType: 'VOD',
            segments: [{ uri: 'media-0.m4s', duration, sequence: 0,
                discontinuitySequence: 0, map: { uri: 'init.mp4' } }],
        });
    } catch (error) {
        await Promise.allSettled(sinks.map(sink => sink.abort(error)));
        throw error;
    }
}
```

複数セグメントでは同じwriterへ継続してサンプルを追加し、適切な境界で`flush()`または`flushTo()`します。`flush()`は結合済み`data`を返し、`flushTo()`はSinkのbackpressureを待って書き、メタデータだけを返します。writerはSinkをcloseしません。`flushTo()`の完了前にwriterを変更しないでください。最初のwrite開始後の書き込み・中止失敗は終端状態です。出力開始前の設定拒否や中止は、データを保ったまま再試行できます。

映像fragmentは既定でキーフレーム開始が必要です。`requireKeyframe: false`は同一セグメント内の依存chunkなどを明示的に許可する設定で、独立して復号できる保証を追加するものではありません。複数トラックではトラックごとの時刻・サンプル数を維持し、配信側がセグメントの境界を揃えます。

## 断片のイベントとproducer時刻

`addEvent()`は次の空でない断片へemsgを追加します。時刻に応じた自動振り分けは行いません。v0のdeltaはその断片の表示開始に対する差、v1のpresentationTimeは指定timescaleの絶対tickです。

```ts
import { type CmafWriter, type CmafSegment } from 'mediaforgejs';

export function flushWithEvent(writer: CmafWriter, trackId: number): CmafSegment {
    writer.addEvent({ version: 1, schemeIdUri: 'urn:example:event', value: '',
        timescale: 1000, presentationTime: 1000n, eventDuration: 250, id: 1,
        messageData: new TextEncoder().encode('chapter') });
    return writer.flush({ producerReferenceTime: {
        trackId, ntpTimestamp: 3908988800n << 32n, mediaTime: 1000n,
    } });
}
```

この関数はサンプルを追加済みのwriterを受け取ります。prftの`trackId`はその断片に存在するトラック、`mediaTime`は同トラックの表示tick、`ntpTimestamp`はNTPのunsigned 32.32形式です。出力順はemsg列、任意prft、moof、mdat。`maxBufferedEvents`は標準1000、0で追加禁止にできます。イベントだけの断片は出せないため、容量の小さいwriterでは先にサンプルを追加し、イベント用の余裕を確保してください。

## 単位と符号化設定

| 入力 | 単位・内容 |
| --- | --- |
| HLS `duration`、`targetDuration` | 秒。targetDurationは正の整数 |
| `CmafTrack.timescale` | 1秒あたりのtick数 |
| `addSample()`のdecodeTimestamp・duration・compositionTimeOffset | トラックのtick。decodeTimestampは`bigint`または安全な整数 |
| `addChunk()`のtimestamp・decodeTimestamp・duration・compositionTimeOffset | 秒。writerがtimescaleへ丸めて変換 |
| `CmafSegmentTrack.baseDecodeTime`・duration | tickの`bigint` |
| `MediaFile.packets()`の時刻・duration | 秒 |

長い素材で厳密な時刻を渡す場合は、サンプル数から整数tickを積算して`addSample()`を使います。DTSは復号順、PTSは表示時刻です。compositionTimeOffsetはPTS−DTSです。

`codecConfig`はMP4 box全体ではなく設定payloadです。AVCはavcC、HEVCはhvcC、AV1はav1C、VP9はversion/flagsを含むvpcC payload、AACはAudioSpecificConfig、OpusはdOps、FLACは34バイトのSTREAMINFO、AC3は3バイトのdac3、EAC3は5バイトのdec3（旧FFmpegの末尾ゼロ付き6バイトも可）、ALACは24バイトのALACSpecificConfig、WebVTTはUTF-8のvttCを渡します。AVC/HEVCサンプルは設定された幅のlength prefix付きNALで、Annex Bではありません。AACサンプルにADTSヘッダーを付けません。字幕の`wvtt`サンプルはMP4 WebVTT cue box列です。boxを構築できることと、配信先のCMAF/HLSプロファイルやデコーダーが対応することは別に確認してください。

## 制限と資源

HLS取得はHTTP(S)とWeb標準のFetch/Streamsを使います。`fetch`を注入して認証ヘッダーなどを設定できます。リクエストごとの既定期限は30000 msでヘッダーと本文の両方を含みます。`maxPlaylistEntries`はsegments・PART・復元履歴を合わせた個数の上限で標準100000です。既定のバイト上限はプレイリスト2 MiB、各セグメント・各MAP64 MiBで、`maxPlaylistBytes`・`maxSegmentBytes`から変更できます。キーは16バイトです。応答はストリームで上限を確認しますが、返却用の連続配列、復号、Sourceへのコピーなどで追加メモリを使うため、この上限はプロセス全体のメモリ上限ではありません。呼び出し側が結果を保持した分も別途必要です。

`CmafWriter`の既定バッファ上限はサンプルpayloadと符号化済みemsgの合計16 MiB・100000サンプル・1000イベントです。上限前に利用側がflushします。moof/mdatヘッダー、prft、初期化データ、返却配列の領域は別です。

- 組み込みの暗号化処理はWebCryptoによるidentity AES-128/CBCに対応します。この形式の初期化MAPには明示IVが必要です。SAMPLE-AESは`drm/sample-aes`、DRMは`streaming/hls-drm`を選択して利用できます。暗号化I-frame playlistの特殊な範囲復号は対象外です。
- EAC3の追加sample entryは独立substream1本・従属なし・拡張なし、ALACは16/20/24/32bit・1〜8ch・65535Hz以下です。対応ファミリー名だけでは任意の設定を書けません。
- ABR、自動rendition切替、変数置換、再生時計、デコーダー制御、ブラウザでの自動再生は提供しません。CORSなどFetchの実行環境の制約が適用されます。
- HLS/CMAF全仕様への適合を保証するものではありません。対象のcodec/profile、プレーヤー、セグメント境界を実際の配信条件で確認してください。

仕様: [RFC 8216](https://www.rfc-editor.org/rfc/rfc8216.html)、[Apple HLS Authoring Specification](https://developer.apple.com/documentation/http-live-streaming/hls-authoring-specification-for-apple-devices)、[Apple Low-Latency HLS](https://developer.apple.com/documentation/http-live-streaming/enabling-low-latency-http-live-streaming-hls)。

## ブラウザー標準EME

`EmeController`は`HTMLMediaElement`へMediaKeysを接続し、`encrypted`イベントから一時セッションを作成します。ライセンス通信と認証はアプリのcallbackが担当し、ライブラリから暗黙に外部サーバーへ送信しません。

```ts
import { EmeController, createClearKeyLicense } from 'mediaforgejs';

export async function attachClearKey(
    video: HTMLVideoElement,
    keys: Readonly<Record<string, string>>,
    signal?: AbortSignal,
): Promise<EmeController> {
    return EmeController.attach(video, {
        keySystem: 'org.w3.clearkey',
        configurations: [{
            initDataTypes: ['cenc', 'keyids'],
            videoCapabilities: [{ contentType: 'video/mp4; codecs="avc1.42E01E"' }],
            sessionTypes: ['temporary'],
        }],
        license: createClearKeyLicense(keys),
        signal,
        onError: error => console.error(error),
    });
}
```

`keys`はKIDからAES-128キーへの対応で、どちらもpaddingなしの正規base64urlです。指定されていないKIDは拒否します。既存のMediaKeysを持つ要素は引き継ぎません。メディアURLはattach成功後にアプリが設定してください。

任意の対応key systemでは`license(request)`に`message`、`messageType`、`sessionId`、`keySystem`、`signal`を渡します。callbackはCDMが要求する応答のUint8Arrayを返します。同一セッションのlicense処理は直列化されます。標準上限は一時セッション8個、init data 1 MiB、各message/license 1 MiB、処理中を含むmessage16個、callbackとupdateの期限30秒です。

`addSession(type,bytes)`は同一init dataを重複作成せず、generateRequest完了時に返ります。ライセンス取得完了の保証ではありません。`sessionCount`、選択された`configuration`、`failure`、終了Promiseの`done`を参照できます。`done`はcloseで完了し、CDM・ライセンス失敗・中止で拒否します。

終了時はアプリ側で再生とMSEを終了し、必要ならvideoのsrcを外して`load()`してから`await controller.close()`します。ブラウザーによっては使用中のメディアパイプラインからMediaKeysを外せません。controllerはアプリのURL・MSEを勝手に破棄しません。

3.11.0ではEME/MSEモデルで接続、セッション、ライセンス更新、中止、解放を検証しています。実ブラウザー・商用CDMと実ライセンスサービスによる連続再生は未確認です。CDM・secure context・codec・暗号化形式の対応はブラウザー側の条件です。HLSの自動接続、証明書とHTTPライセンス取得は[暗号化HLSとDRM](PROTECTED-HLS-JA.md)を参照してください。永続ライセンスとライセンスサーバーの提供は含みません。

参照: [Encrypted Media Extensions](https://www.w3.org/TR/encrypted-media/)。

## HLSの自動画質選択

VOD・時刻を対応付けられるライブ配信の完成セグメントと公開済みPARTを自動選択できます。`HlsClient`は取得するメディアを選ぶAPIです。fMP4を再生する場合は、後述の`playHls()`へ`parts()`を渡せます。

```ts
import { HlsClient } from 'mediaforgejs/streaming/hls';
const client = new HlsClient({
    adaptive: {
        bandwidthSafetyFactor: 0.75,
        upSwitchSegments: 3,
        onVariantChange: event => console.log(event.reason, event.variant.bandwidth),
    },
});
try {
    await client.load(masterUrl);
    for await (const unit of client.segments()) {
        console.log(unit.variant, unit.segment.sequence, unit.initData, unit.data);
    }
} finally { client.close(); }
```

`adaptive:true`は同じ既定設定を使います。initialBandwidth（bit/s）省略時は最低帯域から開始。取得時間と取得byte数を2秒・5秒のEWMAで追跡し、低下時は直近値も使って次の境界で下げ、上げる場合は既定3回のサンプルを要求します。アプリ側の処理待ち時間は測定に含めません。切替時は必要な初期化bytesを再通知します。onVariantChangeはPromiseも受け取り、中止可能です。

VODでは同じcodec・audio/video/subtitle等group、独立セグメント、同じ全sequence・時間境界・不連続・gapを要求します。双方のPDTも照合し、PDTのない同一masterのVODは共通の先頭を前提とします。ライブでは`segments({live:true})`を使い、PROGRAM-DATE-TIMEまたは共有する不連続境界から同時刻の窓を照合します。画質間のMEDIA-SEQUENCEは異なっても構いませんが、番号の一致だけでは切り替えません。候補が古ければ再取得し、不一致は`HLS_ADAPTIVE_ALIGNMENT`、候補の取得失敗は`HLS_ADAPTIVE_UNAVAILABLE`で通知して現在の画質を続行します。切り替え時の`initData`を消費側で適用してください。`playHls()`はこの適用を行います。別renditionの同期は含みません。

`parts()`にも同じ`adaptive`設定を使えます。

```ts
for await (const unit of client.parts({ live: true, maxIdleRefreshes: 10 })) {
    if (unit.type === 'part') {
        console.log(unit.variant, unit.sequence, unit.partIndex, unit.initData, unit.data);
    } else {
        console.log(unit.variant, unit.segment.sequence, unit.initData, unit.data);
    }
}
```

PART切り替えにはPDTまたは共有する不連続境界の時刻が必要です。ENDLISTのある配信にもこの条件を適用します。親の開始時刻・不連続番号・PARTの累積時間・切替単位の長さを照合し、対象が独立PART（または独立セグメント保証のある先頭PART）であることを確認します。画質間でMEDIA-SEQUENCEやPART番号が異なっても、これらが合えば切り替えます。取得済みの親セグメントを完成後に全体として二重取得しません。

変更通知の`sequence`・`partIndex`は実際に選んだ画質の番号です。PART取得の初期通知は先頭GAPを除いた最初の取得対象を示し、すべてGAPの窓では通知を出しません。初期選択・完成セグメント切り替えの通知はダウンロード前、PART切り替えの通知は候補のMAP・PARTを取得できた後、返却前です。PARTの候補取得に失敗した場合は警告して現在の画質を続け、偽の切り替え通知を出しません。選択済み画質のリソース失敗、通知コールバックの拒否、中止は停止条件です。返却値の`variant`はそのbytesを取得した画質を示し、切り替え時の初期化bytesは`initData`で再通知します。

公開済みの非暗号化PARTとAES-128 identityのPARTが対象です。暗号化された候補はMAP・鍵・PARTの取得と復号まで成功してから切り替えます。バイト列のfMP4妥当性をこのクライアントが全面検証するものではありません。時刻・独立境界が不足する候補では現在の画質を維持します。blocking reloadとPRELOADの先行取得は含みません。3.11.0のSAMPLE-AES・DRMハンドラーも利用でき、[暗号化HLSとDRM](PROTECTED-HLS-JA.md)の形式・再生条件が適用されます。

`mediaforgejs/streaming/adaptive`の`AdaptiveQualityController`は取得から独立した帯域選択器です。`addSample(bytes, elapsedMs)`, `selectBandwidth(availableBps,currentBps?)`, `bandwidthEstimate`を提供します。DASHにも呼出側から利用できますが、DASHの自動取得を提供するものではありません。

## 暗号化PARTの復号

`METHOD=AES-128`、`KEYFORMAT=identity`（省略も可）に対応します。鍵は16 bytes、CBCとPKCS#7 paddingを使います。各PARTのリソースまたは指定範囲は、それ自体が完全な暗号文である必要があります。IVは明示値を使い、省略時は親のMEDIA-SEQUENCEを128bit big-endianへ変換します。PART番号をIVへ加算しません。暗号化MAPには明示IVが必要です。

鍵URIの切り替え、MAPとPARTで異なる鍵、`METHOD=NONE`への移行、各PARTを独立して暗号化したbyte rangeを扱います。親全体のCBC暗号文を任意の位置で切り出す形式、I-frame playlistの特殊な範囲復号、SAMPLE-AES/CTR、AES-256-GCMはこの復号経路の対象外です。鍵の取得失敗・不正長・不正paddingは、その選択済み入力の処理を停止します。PART切り替え候補だけの失敗は警告して元の画質を続けます。

復号にはWebCryptoのAES-CBCが必要です。鍵と暗号文の取得に既存のリソース上限・タイムアウト・中止が適用され、候補を採用する前に復号を終えます。暗号化や鍵の配布は利用側の配信設備が担当します。[HLS第2版の作業草案](https://datatracker.ietf.org/doc/html/draft-pantos-hls-rfc8216bis-22)のPART、KEY、MAPの規則を参照してください。

## ブラウザーでの連続再生

`playHls()`は、`HlsClient.parts()`の非同期イテレーターをMSEへ順番に投入します。取得側と再生側を別の入口から組み合わせられます。

```ts
import { HlsClient } from 'mediaforgejs/streaming/hls';
import { playHls } from 'mediaforgejs/streaming/hls-playback';

export async function play(video: HTMLVideoElement, masterUrl: string, signal: AbortSignal): Promise<void> {
    const client = new HlsClient({ signal, adaptive: true });
    try {
        await client.load(masterUrl);
        await playHls(video, client.parts({ live: true }), {
            signal,
            mimeType: 'video/mp4; codecs="avc1.42c00a,mp4a.40.2"',
            bufferAhead: 30,
            bufferBehind: 30,
        });
    } finally {
        client.close();
    }
}
```

MIMEは実際の配信コーデックに合わせます。省略時は`unit.variant.codecs`のAVC/AACから推定します。ブラウザーがMSEで受け付けるfMP4が対象で、各入力は完全なmoof/mdatを含む必要があります。映像と音声を各1トラックまで同一fMP4に収めた配信、映像のみ、音声のみを扱います。edit listは省略またはmedia time=0・rate=1の単一エントリーに限定します。TSの自動transmux、別URLの音声・字幕renditionの取得と同期は対象外です。DRMライセンスとの自動連携には`playHlsWithDrm`を利用します。

`autoplay`の既定は`true`です。再生要求の拒否は呼び出し元へ返します。アプリ側で再生を開始する場合は`autoplay:false`を指定します。一時停止・再開は`video.pause()`と`video.play()`、終了は渡した`AbortSignal`で操作します。Promiseは入力の終了に加えてメディア要素の`ended`まで待ちます。ライブ入力はENDLISTまたは取得側の正常終了まで続きます。

初期化データとメディアを直列にappendし、初期化データの変更を反映します。通常区間のPTSと音声・映像の時間差を保ち、先頭の時刻と不連続区間の時刻原点を調整します。`operationTimeoutMs`（既定30000 ms）はMSEの開始・append・remove待ちの期限です。一時停止や最後の再生完了待ちには適用しません。

`bufferAhead`・`bufferBehind`は秒単位です。先の再生バッファが上限に達したら次の取得を止め、再生済みの範囲を除去します。1入力分は先読み目標を超えることがあります。後方の除去位置は既知のランダムアクセス境界まで戻すため、長いGOPは指定時間より長く残ります。無制限の先読みキューは作りません。中止・失敗・完了時には、この呼び出しが作ったSourceBuffer・MediaSourceへの接続、リスナー、object URLを解放します。呼び出し中にアプリが`src`を置き換えた場合、その新しい接続は解放しません。

3.10.0の実ブラウザー再生試験は、検証環境のサーバー接続・ローカルページ読込制限で実行できていません。MSE代替を使う回帰試験と実HTTPの復号試験を、ブラウザーの連続再生成功としては扱いません。実ブラウザーでの対応確認は残っています。
