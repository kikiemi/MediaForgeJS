# 実ブラウザー CI

`.github/workflows/browser-ci.yml` は、Google Chrome、Mozilla Firefox、macOS 標準 Safari を各製品の WebDriver で実行する。Selenium / Playwright の追加依存はなく、Node.js 標準の HTTP と W3C WebDriver プロトコルを使う。Safari ジョブの対象は `/usr/bin/safaridriver` が操作する Safari である。

## 実行環境と証拠の範囲

| ジョブ            | ブラウザー / ドライバー       | 実行環境                               | 検証できる範囲                                         |
| ----------------- | ----------------------------- | -------------------------------------- | ------------------------------------------------------ |
| `chrome`          | Google Chrome / ChromeDriver  | `macos-15-intel`                       | macOS VM 上の製品 Chrome、ネイティブ音声デコード、MSE  |
| `firefox`         | Mozilla Firefox / geckodriver | `macos-15-intel`                       | macOS VM 上の製品 Firefox、ネイティブ音声デコード、MSE |
| `safari`          | Safari / SafariDriver         | `macos-15-intel`                       | macOS VM 上の標準 Safari、ネイティブ音声デコード、MSE  |
| `physical-safari` | Safari / SafariDriver         | 手動登録した `mediaforge-physical-mac` | 手動実行を選んだ物理 Mac 上の Safari                   |

macOS VM の成功は、物理 Mac、iPhone、iPad の成功を意味しない。物理 Mac 用ジョブも iOS を対象にしない。ラベルと `runnerKind` は管理者による環境の申告であり、物理機器の自動認証ではない。実機結果を公開する場合は、管理者が機器・OS・ブラウザー・コミット・実行日時を確認して結果と併記する。

iOS の実機自動化には、Mac に接続・信頼済みでロック解除された機器、機器側の Remote Automation、`platformName: "ios"` など、別の SafariDriver 設定が必要になる。このハーネスはループバック HTTP だけにバインドし、iOS への配信・機器選択は実装していない。iOS / iPadOS、ハードウェアデコーダー固有の動作、外部スピーカーで実際に音が出ることは検証済みと記載しない。

## 必須チェック

| チェック                  | 判定                                                                                                                                                                                                                                    |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `canonical-globals`       | minified bundle の `MediaForgeJS`、`MediaForgeJSReady`、ready イベントを検証。既定 bundle に `FlowCast` / `FlowCastReady` や AMD ローダーのグローバルがない                                                                             |
| `native-pcm-decode`       | ブラウザーの `OfflineAudioContext.decodeAudioData()` で生成 WAV をデコードし、チャンネル数・サンプルレート・長さ・音声成分を検証                                                                                                        |
| `native-aac-m4a-decode`   | プロジェクト自身が生成した AAC-in-M4A をネイティブデコーダーでデコードし、同じ音声成分を検証                                                                                                                                            |
| `self-hosted-aac-decode`  | ADTS から切り出した AAC をブラウザー内の自前デコーダーで復号し、同じ独立した音声判定を適用                                                                                                                                              |
| `mse-continuous-playback` | `HlsClient.parts()` → `playHls()` → 本物の `MediaSource` / `SourceBuffer`。全フラグメントの供給、ネイティブ `updateend`、境界前後の media clock と経過時間の整合、seek / 途中の stall がないこと、末尾の `ended`、所有 URL の解放を検証 |
| `playback-cancellation`   | 再生開始後かつ未完了の iterator が残る時点で abort。`ABORT`、iterator の `return()`、要素の src と所有 URL の解放を検証                                                                                                                 |
| `capability-reporting`    | `probeNativeCodec()` の結果を実際のブラウザー API と照合。MSE、`canPlayType`、WebCodecs、AudioContext、UA を保存                                                                                                                        |

音源は `test/browser/fixtures.mjs` が毎回生成するオリジナルの 48 kHz / stereo / 3.072 秒 PCM。左 997 Hz、右 1499 Hz、振幅 0.22、両端 10 ms の fade を含む。そこから MediaForgeJS 自身で ADTS AAC、M4A、CMAF init と約 0.512 秒単位のメディアフラグメント、VOD playlist を生成する。ダウンロード音源や FFmpeg は使わない。各ファイルの SHA-256 と生成条件を `fixtures/manifest.json` に保存する。

独立した数学的判定器 `signal.mjs` は、自前 AAC デコーダーの結果を正解データとして利用しない。両チャンネルの全サンプルが有限値であることを検査する。音声成分は、10 ms fade と AAC priming / padding のために両端 64 ms だけを除外し、それ以外の全範囲を最大 500 ms の窓に分けて検査する。各窓で RMS が 0.08–0.25、期待周波数のエネルギー比が 0.85 より大きいことを要求する。先頭だけ正しい音声、途中からの無音・周波数違い・左右入れ替え、末尾の非有限値は通らない。AAC の priming / padding とネイティブ edit-list 処理差を許容するため、音声長の許容差は 2 AAC access units（約 42.7 ms）。これは一般的な音質認証や全コーデックの互換性保証ではない。

必須 AAC / MSE が未対応ならジョブを失敗させる。未対応を skip に置き換えて成功にしない。WebCodecs の AAC は追加チェックであり、未提供・未対応なら理由付き `unsupported` として記録する。WebCodecs が対応を申告した場合は実際に `AudioDecoder` へ AAC packet を入力し、復号 PCM を同じ判定器で確認する。この追加チェックの失敗もジョブを失敗させる。ネイティブ M4A デコードと MSE 再生は WebCodecs の有無にかかわらず必須である。

## CI を動かす

ワークフローを含む変更を GitHub リポジトリに反映すると、push / pull request、手動の `workflow_dispatch`、平日 04:23 UTC の `schedule` で 3 製品のジョブを実行できる。定期実行は既定ブランチの最新コミットを対象とする。GitHub 側の混雑による遅延・取りこぼし、公開リポジトリの無活動によるスケジュール無効化は別途確認する。この配布物の作成時点では、GitHub への反映や Actions 実行は行っていない。

各ジョブは Node.js 24、`npm ci`、`npm run build`、Node 専用ハーネステスト、実ブラウザーの順に実行する。ブラウザーとドライバーは GitHub runner image にあるものを使用する。Chrome と Firefox は headless、Safari は通常の automation window。Safari の VM ジョブは `sudo /usr/bin/safaridriver --enable` を実行する。音声は muted で、再生開始には WebDriver の Element Click によるユーザー操作を与える。

`macos-15-intel` の image とブラウザーは更新されるため、この CI は固定バージョンの完全な再現環境ではない。実行時の `browserVersion`、WebDriver capabilities、image version、Node version、対象 bundle の SHA-256、GitHub commit / run ID を `report.json` に保存する。ドライバーとブラウザーの不一致、起動できない環境、MSE の未対応は診断付き失敗になり、別エンジンに自動置換しない。

## 手元でのコマンド

ブラウザーが利用できる macOS 環境で実行する。ChromeDriver と geckodriver は事前に導入し、それぞれブラウザーのバージョンに合わせる。Safari の Remote Automation は、その Mac の管理者が事前に有効にする。

```sh
npm ci
npm run build
node --test test/browser/harness.test.mjs
node scripts/browser-ci.mjs --browser chrome
node scripts/browser-ci.mjs --browser firefox
node scripts/browser-ci.mjs --browser safari
```

Node だけで fixture とハーネスを検証する場合:

```sh
node --check scripts/browser-ci.mjs
node --check test/browser/suite.mjs
node --test test/browser/harness.test.mjs
node scripts/browser-ci.mjs --prepare-only
```

`--prepare-only` は HTTP 配信、ドライバー、ブラウザーを起動しない。`report.json` の `mode` は `prepare-only`、`status` は `prepared`、`browserExecuted` は `false` になる。Node ハーネステストは本物の HTTP range 処理と W3C リクエストをローカルのプロトコルモデルで検査するが、ブラウザー実行の証拠にはならない。作成時のローカル確認はこの範囲に限定されており、3 製品の実行成功は未確認である。

| 指定                                                                             | 用途                                                    |
| -------------------------------------------------------------------------------- | ------------------------------------------------------- |
| `--dist PATH` / `MEDIAFORGE_BROWSER_DIST`                                        | 別の build 出力から ESM と `MediaForgeJS.min.js` を読む |
| `--out PATH`                                                                     | fixture、report、driver log、失敗時 screenshot の出力先 |
| `MEDIAFORGE_CHROME_BINARY` / `MEDIAFORGE_FIREFOX_BINARY`                         | 実際の製品ブラウザーの実行ファイル                      |
| `MEDIAFORGE_CHROMEDRIVER` / `MEDIAFORGE_GECKODRIVER` / `MEDIAFORGE_SAFARIDRIVER` | 各ドライバーの実行ファイル                              |
| `CHROMEWEBDRIVER` / `GECKOWEBDRIVER`                                             | GitHub image が提供するドライバー格納ディレクトリ       |
| `MEDIAFORGE_BROWSER_PORT` | ループバックHTTPのポート。通常は自動選択、DRMサービスでは既定4173 |

macOS 以外で Safari を選ぶと明示的に失敗する。既定の検証対象は macOS。Linux の Chrome / Firefox 用既定パスもあるが、Linux のプラットフォームコーデック可用性をこの matrix の結果で保証しない。

## 物理 Mac の任意ジョブ

信頼できる物理 Mac の self-hosted runner に `macOS` と `mediaforge-physical-mac` ラベルを付け、Safari Remote Automation を管理者が有効化する。手動実行時に `physical_safari` を選ぶ。pull request だけでこのジョブが実行されることはない。runner は対応する Actions の必要バージョンに更新しておく。物理 iPhone / iPad の結果を必要とする場合は、別の端末設定とハーネスを追加し、その端末で実行結果を取得する。

## 結果の読み方

通常の出力先は `artifacts/browser/<browser>/`。CI はジョブが失敗してもこのディレクトリを artifact として保存する。

- `report.json`: 実際のブラウザー ID / capabilities、実行環境、各必須チェックの結果、追加コーデックの制約、page error。
- `fixtures/`: 使用したオリジナル音源、CMAF、playlist、各ファイルの hash。
- `webdriver.log`: ドライバーの stdout / stderr。
- `failure.png`: WebDriver session が残り、screenshot を取得できる失敗の場合のみ。

`status: "passed"` は、実ブラウザーの session が開始し、全必須チェックが各 1 回成功し、page error がない場合だけ出力する。`browserExecuted: true` 単独は session が作られたことだけを意味するため、必ず `status` と各テストを確認する。途中 timeout、必須チェック欠落、`unsupported`、未処理例外は成功扱いにしない。

## 認証済み商用DRMサービスの任意CI

`commercial-drm` は通常の音声・MSE検証と別のジョブである。Chrome / Firefox は `com.widevine.alpha`、Safari は標準EMEの `com.apple.fps` を要求する。3製品とも通常のウィンドウで実行し、ブラウザーが提供するCDMと、管理者が明示したライセンスサービスだけを使用する。ClearKeyやNodeのプロトコルモデルを商用DRMの成功として扱わない。

管理者は、許可を得たテストコンテンツ、ライセンスサービスのURL・認証、FairPlayの実サービス証明書を用意する。サービスと配信元は `http://127.0.0.1:4173` からのCORSアクセス、必要なPOST・Range・Authorizationなどのヘッダーを許可する。ポートを変える場合は `MEDIAFORGE_BROWSER_PORT` とサービスの許可元を合わせる。サービスが要求するrobustness、出力保護、CDMの利用条件をそのrunnerが満たす必要がある。

| GitHub repository secret | 対象 |
| --- | --- |
| `MEDIAFORGE_DRM_CHROME` | Chrome用のJSON設定 |
| `MEDIAFORGE_DRM_FIREFOX` | Firefox用のJSON設定 |
| `MEDIAFORGE_DRM_SAFARI` | Safari用のJSON設定。FairPlay証明書を含む |

設定形式と再生対象の条件は [PROTECTED-HLS-JA.md](PROTECTED-HLS-JA.md#実サービス検証の設定) に記載する。設定は秘密値として環境変数 `MEDIAFORGE_DRM_SERVICE_JSON` へ渡し、シェルコマンドに直接埋め込まない。

既定ブランチで手動実行の `commercial_drm` を選ぶと実行する。定期実行にも含める場合は repository variable `MEDIAFORGE_DRM_CI_ENABLED` を `true` にする。DRMジョブはpull requestや既定ブランチ以外では実行しない。設定を渡すのはサービス実行のステップだけである。

```sh
# MEDIAFORGE_DRM_SERVICE_JSON は事前に秘密管理から環境へ注入する。
node scripts/browser-ci.mjs --browser chrome --drm-service --prepare-only
node scripts/browser-ci.mjs --browser chrome --drm-service --require-service
```

設定がない場合は、ネットワーク・ドライバー・ブラウザーを使う前に `status: "skipped"`、`browserExecuted: false`、`serviceExecuted: false` を保存する。CIが使う `--require-service` は、このスキップを終了コード1にして、設定漏れでジョブが成功することを防ぐ。設定ありの `--prepare-only` も `prepared` であり、サービスの接続確認ではない。CDM未提供、ライセンス拒否、証明書不適合、CORS失敗、再生失敗はskipへ変更せず失敗にする。

成功には、ライセンス応答、CDMからのusable鍵、暗号化されたHLS区間、期待するVOD末尾の `ended`、実時間に沿ったmedia clock進行、MediaKeysとsrcの後始末が必要である。鍵入れ替えを検証するときは `minUsableKeys` と `minKeyChanges` も設定する。ネイティブブラウザーCIの成功だけでは、このサービス検証の成功にならない。

DRMのartifactは `artifacts/browser/drm-<browser>/report.json` だけを保存する。サービスURL、認証ヘッダー、証明書、鍵ID、challenge、license bytesはレポートへ入れない。サービス設定はループバックサーバーのメモリーで渡し、設定ファイル・WebDriverログ・スクリーンショットは保存しない。エラーは `configuration` / `capability` / `manifest` / `playback` / `evidence` / `cleanup` などの段階だけを示す。`serviceExecuted: true` はライセンス応答を受信したことを示すだけなので、必ず `status` と証拠カウンターも確認する。

この配布物には、実サービスアカウント・認証済みGitHub実行・商用CDMの成功記録は含まれていない。Node回帰テストと準備モードは構成・通信境界・結果判定を確認するが、実サービス互換性の証明にはならない。実際の3製品・サービスごとの検証結果は、上記設定を投入した権限のあるrunnerで取得する必要がある。

## 参照した一次資料

2026-09-25 確認。ブラウザー / image の版数を本文に固定せず、実行結果の版数を記録する。

- [ChromeDriver capabilities / ChromeOptions](https://developer.chrome.com/docs/chromedriver/capabilities): `goog:chromeOptions` と製品 Chrome の binary 指定。
- [ChromeDriver version selection](https://developer.chrome.com/docs/chromedriver/downloads/version-selection): ブラウザー / ドライバーの版数の対応。
- [Firefox geckodriver capabilities](https://firefox-source-docs.mozilla.org/testing/geckodriver/Capabilities.html) / [flags](https://firefox-source-docs.mozilla.org/testing/geckodriver/Flags.html): Firefox 固有設定とドライバーの起動。
- [Apple: Testing with WebDriver in Safari](https://developer.apple.com/documentation/webkit/testing-with-webdriver-in-safari) / [WebKit: WebDriver on iOS](https://webkit.org/blog/9395/webdriver-is-coming-to-safari-in-ios-13/): SafariDriver と実機 iOS の別要件。
- [GitHub macOS 15 Intel runner image](https://github.com/actions/runner-images/blob/main/images/macos/macos-15-Readme.md): プリインストールされたブラウザー / ドライバーと環境変数。
- [actions/checkout](https://github.com/actions/checkout)、[actions/setup-node](https://github.com/actions/setup-node)、[actions/upload-artifact](https://github.com/actions/upload-artifact): 確認時の公式使用例に合わせて `@v7` を使用。
- [GitHub: schedule](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule) / [secrets](https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets): 既定ブランチの定期実行とsecretの環境変数注入。
- [GitHub-hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners): `macos-15-intel` のrunnerラベル。
