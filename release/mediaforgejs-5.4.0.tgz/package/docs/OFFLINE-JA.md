# オフライン・ローカル利用

配布物の `release/` ディレクトリ全体と、Node.js・npm をオフライン環境へ持ち込みます。通常の npm 公開用 tarball は本体と6拡張の7個です。ProRes 用の外部依存と検証・開発用ツールは、これらを膨らませず `release/offline/` に別梱包しています。

## キャッシュなしでインストール

ソース ZIP を展開したディレクトリで実行します。インストール先は空のディレクトリ、または未作成のパスを指定してください。

```sh
node release/offline/install.mjs ./offline-consumer
```

このコマンドは manifest と全 tarball の SHA-256・SHA-512、名前・版、ライセンス情報を照合し、利用側の `package.json` にローカル tarball だけを指定します。空の専用 npm キャッシュを作り、`--offline --ignore-scripts`、更新通知無効、ローカルの無効なレジストリ、Node のネットワーク API 遮断を組み合わせてインストールします。既存の開発用 `node_modules` や共有 npm キャッシュは使いません。展開した各ファイルも tarball 内の内容と照合します。

```sh
cd offline-consumer
node --input-type=module -e "import('mediaforgejs-prores').then(m => console.log(typeof m.createProResDecoder))"
```

自分のアプリに組み込むときは、生成された `package.json` の `file:` 指定を参照してください。移動後に再インストールする場合は tarball のパスも更新します。インストール後の実行に `release/` のパスや npm キャッシュは必要ありません。

## 同梱する依存

| 配布先 | パッケージ | 版 | ライセンス |
| --- | --- | --- | --- |
| `offline/dependencies/` | `turbores` | 1.2.2 | MPL-2.0 |
| `offline/dependencies/` | `prores-wasm-encoder` | 1.0.0 | LGPL-2.1-or-later |
| `offline/dependencies/` | `@rollup/rollup-linux-x64-gnu` | 4.62.1 | MIT |
| `offline/toolchain/` | `typescript` | 5.9.3 | Apache-2.0 |
| `offline/toolchain/` | `prettier` | 3.9.9 | MIT |

外部 tarball は `package-lock.json` の取得元 URL と SHA-512 に一致する上流の原本です。インストール済みディレクトリを再梱包していません。`manifest.json` に元 URL、完全な版、両ハッシュ、依存関係、OS/CPU/libc 制約、同梱ライセンス文書のパスとハッシュを記録します。

Rollup のネイティブパッケージは TurboRes の公開メタデータにある optional dependency のため保持します。Linux x64 glibc 以外では npm が上流の OS/CPU/libc 制約に従って省略し、インストーラーはその理由を出力します。対応する環境での欠落はエラーです。この上流 tarball 自体には LICENSE ファイルがなく、manifest の `licenseFiles` は空配列、ライセンス指定は MIT です。ライセンス文書を持つ他の archive では原文をそのまま保持します。

`prores-wasm-encoder` の `mediabunny` は別製品との連携用の optional peer で、MediaForgeJS の通常の ProRes API は使いません。この未導入 peer を manifest の `optionalPeers` に明示します。`prores-wasm-encoder/mediabunny` を直接使う場合は別途その依存も用意してください。必須依存・optional dependency が不足した配布物は検証を通りません。将来の依存更新で同名パッケージの複数版が必要になった場合も、現在のインストーラーは不完全な配布を作らず梱包時に停止します。

## ソース ZIP から独立した利用側検証

ビルド済みの `release/` を含むソース ZIP では、開発用依存をインストールする前に実行できます。

```sh
node scripts/release.mjs verify
```

本体・6拡張・実行時依存の利用側と、TypeScript・Prettier 専用のツール環境をそれぞれ新規作成します。両方とも空の専用キャッシュとローカル tarball だけでインストールします。これらの開発ツールは通常の利用側へ追加しません。

公開された全型付き entrypoint を `NodeNext / strict / skipLibCheck:false` で検証し、AAC・PCM・M4A、Workflow の変換・リマックス・ストリーム出力、実際の ProRes 符号化/復号と Workflow 変換、合成 ProRes RAW の復号も実行します。実行時も Node のネットワーク API を遮断します。Node 本体と npm はホストに用意してください。検証済み環境は Linux x64・Node.js 24、他 OS やブラウザーの合格を意味しません。

検証記録の保存と利用側の保持は環境変数で指定できます。

```sh
MEDIAFORGE_RELEASE_REPORT=./release-check.json node scripts/release.mjs verify
MEDIAFORGE_RELEASE_KEEP_CONSUMER=1 node scripts/release.mjs verify
```

TypeScript・Prettier だけを別環境へ展開する場合は次のコマンドを使います。

```sh
node release/offline/install.mjs ./offline-toolchain --toolchain
```

## オフラインでソースをビルド・検証

`node_modules` のない新しいソース ZIP の展開先で実行します。

```sh
node release/offline/install.mjs . --development
npm run build
npm run check
npm run release:pack
npm run release:verify
```

`--development` はソースの `package.json` と `package-lock.json` を変更せず、lockfile の全依存に対応する原本 tarball を検証します。新規の専用 npm キャッシュへそれらのローカル archive だけを登録した後、ネットワークを遮断した `npm ci --offline --ignore-scripts` で開発用依存を展開します。専用キャッシュは終了時に削除します。既存の `node_modules` がある場合は上書きせず停止します。

再梱包時は既存の `release/offline/` にある原本を SHA-512 で照合して使うため、共有 npm キャッシュへの依存はありません。依存を更新したソースでは、変更後の完全な archive 一式を接続可能な環境で取得し直す必要があります。Node.js・npm と実ブラウザー・商用 CDM などのホスト側ソフトウェアはこの依存セットには含みません。

## ローカルブラウザーの ProRes 確認

通常の ProRes 依存は WASM を JavaScript 内に埋め込んでいます。別の `.wasm` ファイルや CDN の URL を指定する必要はありません。ブラウザーで bare import を解決するため、ローカルの JS ファイルを import map で対応付けます。

```sh
node release/offline/browser.mjs ./offline-consumer
```

表示された `http://127.0.0.1:.../` をブラウザーで開きます。サーバーはインストール済みパッケージだけを配信し、CSP でページの外部接続を禁止します。COOP `same-origin`、COEP `require-corp` も設定します。ページは apch/ap4h の実符号化→復号→RGBA変換を行い、寸法・画素差・読み込んだ資産の同一 origin を確認します。実行後に利用側ディレクトリへ `offline-browser-report.json` が保存されます。サーバーを起動しただけではブラウザー検証の合格にはなりません。

既定の decoder は `concurrency:0 / useSharedMemory:false` です。共有メモリーを使う worker モードではブラウザーの cross-origin isolation が必要です。上流 WASM は既定モードでも内部に共有メモリーを作るため、隔離ヘッダーのない全ブラウザーでの動作は保証していません。ブラウザーでは上流が decoder を閉じた後も WASM の共有キャッシュを保持する場合があります。Node のメモリー測定値をブラウザーへ一般化しないでください。

`release:verify` は実ブラウザーを起動しません。報告の `browser.status` は `not-run` です。ブラウザー別の再生、WebCodecs、商用 DRM/CDM、認可済みライセンスサーバーとの通信は別の検証です。HLS・DASH・DRM や外部 FFmpeg をアプリで明示的に使う場合は、それぞれのローカル素材・鍵・エンジンなども別途準備してください。
