# 破損ファイルの回復と回帰検証

## API

```ts
import { MediaEngine } from 'mediaforgejs';

export async function recover(input: Blob): Promise<Blob> {
    const file = await new MediaEngine().open(input, {
        validation: 'compatible',
        maxWarnings: 100,
        onWarning: warning => console.warn(warning.code, warning.message),
    });
    try {
        return await file.toBlob({ format: 'mp4' });
    } finally {
        file.close();
    }
}
```

`MediaEngine`の既定値は`compatible`です。`strict`では回復が必要な構造を拒否します。直接使う`MP4Demuxer`と`TSDemuxer`は既定で厳格です。第3引数に`DiagnosticContext`を渡せます。Converter/Pipelineの読み込みは互換処理を共有し、既存のloggerへ警告します。回復は未対応コーデックのデコーダーを追加する機能ではありません。

任意情報の保持条件は`metadataPolicy`で指定します。既定の`'warn'`は、Matroskaの不正な任意属性や出力で失われるタグ・トラック属性を警告します。`'error'`は検出した損失を`FORMAT`で拒否します。`strict`へ任意情報の扱いを暗黙に結び付けず、構造検証と保持条件を別々に選べます。詳細は[APIの設定表](API-JA.md#寛容な入力と警告)を参照してください。

## 検証した回復

| 元の素材 | 保持する完全なパケット | 処理 |
| --- | --- | --- |
| 0.ts | 動画298、音声234 | 空payloadとPES境界をまたぐNALを処理 |
| annex-b.mp4 | 動画5 | EOFをまたぐサンプルを除外 |
| he-aac-v2.mp4 | 動画4、音声5 | 切断mdatから完全なサンプルを保持 |
| malformed-join.mp3 | 音声327 | 破損196バイトを飛ばし再同期、末尾不完全フレームを除外 |
| no-aud.ts | 動画8、音声1 | 不完全な末尾TS/PESを除外 |
| no-initial-keyframe.ts | 動画78、音声57 | 先頭の非キーフレームを正しく保持 |
| trunc-buck-bunny.mov | 動画78、音声188 | 切断mdat回復、cslgに基づく時刻解釈 |
| vorbis-eos.ogg | 音声365 | 開始granule、1サンプルの丸め差、空EOSを処理 |

TSの動画・音声、通常MP4/MOVの回復済みパケットは元のデータとの比較を実施しています。初期参照フレームがないTSは、次の独立して復号できるフレームまで表示できません。欠けた画像・音声を合成したり、非キーフレームをキーフレーム扱いしたりしません。

HEVC Main/Main10のAnnex-B→MP4はFFmpegで復号画素が一致することを検証しています。hvcCはSPSのプロファイル・制約・chroma・bit depth・temporal情報を使用します。必要なパラメーターセットが不足する場合や矛盾する場合は生成しません。`buildHevcCFromAnnexB`は生成不能の場合`null`を返します。

Vorbisは時刻原点と復号primingを分離します。+83/-17サンプルの原点についてOgg/WebMへのコピー後のPCMを比較しました。負の時刻は表示範囲外として除外します。

## 3.6.0の追加回復

- TSの連続番号欠落、不整合な重複、伝送エラー、不正なPESヘッダー・宣言長を検出します。互換モードでは影響する未完了PESを破棄し、次の確認できるPESから再開します。欠落前後のバイトを連結しません。正常な重複は二重に採用しません。次の音声PESの先頭が失われても、直前の音声PESが宣言長どおり完全に到着しており、ヘッダーも妥当なら保持します。
- 分割MP4は、完全な初期化情報・fragment情報から位置を確定できる完全なサンプルを保持します。最後のmoof自体が切れた場合は、先行する利用可能なfragmentがある場合に限り、未完了moofを除外します。
- ADTS/AACはMP3と同じ制限付き探索を使い、途中の異常バイトやEOFを超える不正なフレーム長から再同期します。パケットAPIとConverterのPCM読み出しが同じフレーム索引を使います。PCEでチャンネル構成を記述するADTSはパケットAPIでは未対応ですが、Converterは引き続き実行環境のデコーダーへのフォールバックを試みます。

TSの1パケット欠落を含む試験では、影響した動画PESだけを除き、残る599動画パケット・431音声パケットのバイト列・PTS/DTS・キーフレーム情報を保持しました。分割AAC/MP4の末尾切断では9パケット中8パケットを保持し、再格納・Converter出力の復号PCMが、完全な8パケットを格納した参照データと一致しました。

## 境界と制限

- MP4/MOVは完全なmoov、分割MP4はさらに採用するfragmentの完全なmoof/traf情報が必要です。moov自体の消失や必須テーブルの破損から、サンプル配置を推測して復元しません。
- サンプルはファイルとmdatの両方の範囲内にある場合だけ採用します。切断されたサンプルを短く切って有効とみなしません。MediaEngineではトラックの宣言durationと回復した最後のサンプル時刻が異なる場合があります。Converter/Pipelineは回復したトラックの変換表示区間を利用可能なサンプルに制限します。
- ADTS/MPEG音声の再同期探索は1回1 MiB以内、固定窓で行います。同じ構成の完全な3フレーム、または終端までの完全な2フレームを確認します。失われた音声の長さは復元せず、保持したフレームを連続して配置します。Xing/LAME gapless trimの完全な解釈は未対応です。
- TSの欠落から再同期できても、参照画像が失われた動画は次の独立復号可能なフレームまで乱れる場合があります。暗号化、壊れた番組表、任意のストリーム種別、1 PES内の任意個数のアクセスユニットを網羅するものではありません。
- HEVCの多層構成、全プロファイルのエンコード・デコード、HE-AAC v2の組み込みデコードを保証しません。パケットの読み書きと、実行環境での復号能力は別です。
- FLAC画像・コメントはcodecConfigを通じて保持します。保持するメタデータ込みの構成は16 MiBまでで、超過時は互換モードで警告、厳格モードで拒否します。未知の全メタデータ形式を横断して変換するものではありません。
- 4.0の標準検証はNodeと独自の生成素材です。実ブラウザーCIは別の検証で、この作業環境では実行していません。Bun/Denoの範囲はRUNTIMES-JA.mdを参照してください。

## 独自コーパスの再実行

4.0では外部メディアを必要とするコーパスを廃止し、独自の決定的な生成素材へ置き換えました。生成器は`test/helpers/original-fixtures.mjs`、固定の期待値・SHA-256は`test/corpus.json`にあります。

```sh
npm ci
npm run build
npm test
npm run test:corpus
```

PCM・定数FLACは実際のサンプル値を検証します。AAC/MPEG/Opusのコンテナ素材にはパケット輸送のためのデータも含み、復号品質の合格とは区別します。別の独自音声テストでは正弦波の周波数・振幅、FLACのPCMハッシュ、チャンネルと区間の処理を検証します。不正入力・回復・メモリ上限の試験も標準テストに含めます。FFmpeg/ffprobeや素材のダウンロードは不要です。

旧コーパスのディレクトリ引数と`--native`オプションは廃止しました。実ブラウザーの復号・連続再生の検証は[BROWSER-CI-JA.md](BROWSER-CI-JA.md)を参照してください。

ソースZIPには分割したテストと生成器を含めます。`npm pack`の利用用パッケージにはテストや生成素材を含めません。

## 切断AVIの明示的な回復

```ts
const job = await workflow.open(source, {
    aviRecovery: 'complete-packets',
    onWarning: warning => console.warn(warning.message),
});
try {
    console.log(job.inspect().tracks.map(track => ({ id: track.id, incomplete: track.incomplete })));
    await job.write(sink, { operation: 'remux', format: 'mkv' });
} finally { job.close(); }
```

`aviRecovery`を省略すると、従来どおり切断を拒否します。`validation:'strict'`も破損を拒否します。回復では完結したチャンクだけを使い、欠落した圧縮データを補完しません。H.264の最後のGOPは表示時刻を確定できる場合だけ保持し、それ以外は警告して落とします。元のヘッダーやSPS/PPSがない入力、完全で時刻の確かなパケットが残らない入力は回復できません。
