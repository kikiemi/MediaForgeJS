# 暗号化HLSとDRM

暗号化の取得・復号は`HlsClient`、ブラウザーのCDM接続は`playHlsWithDrm`へ分けています。SAMPLE-AES、HTTPライセンス取得、DRM再生は個別のサブパスから選択できます。追加の実行時依存パッケージはありません。

## 対応範囲

| 入力 | 処理 | 入口 |
| --- | --- | --- |
| identity AES-128、完全セグメント・独立暗号化PART/MAP | 従来どおりWebCryptoでCBC/PKCS7復号 | `streaming/hls` |
| identity SAMPLE-AES、完全なAVC/AAC MPEG-TS・packed ADTSセグメント | サンプル部分をCBC復号し、利用できるTS/ADTSへ戻す | `drm/sample-aes` |
| fMP4 SAMPLE-AES（cbcs）・SAMPLE-AES-CTR（cenc）、完全セグメント・PART | 暗号化データを維持してブラウザーCDMへ渡す | `streaming/hls-drm` |
| 利用側が実装した暗号方式・鍵形式 | 登録したハンドラーが復号 | `HlsEncryptionHandler` |

ソフトウェアSAMPLE-AESは、188バイトTSパケット、単一プログラム、完全なPESとAVC/AACフレームを扱います。Dolby音声、HEVC、fMP4のソフトウェア復号、リソースをまたぐ不完全なTS/PES、SAMPLE-AESのTS PARTは対象外です。公開サンプル復号関数とソフトウェアハンドラーの入力上限は64 MiBです。1リソースのフレーム/NALとID3タグはそれぞれ最大100,000件です。

DRMはライセンスサービスの設定、認証、対応ブラウザー/CDMを必要とします。ライセンスURLをコンテンツから推測して送信する処理はありません。FairPlayは標準EMEの`com.apple.fps`用で、旧WebKit APIやネイティブ`src=`によるHLS再生を置き換えるものではありません。既存`playHls`のfMP4、トラック、編集リスト、MIME、バッファ条件も適用されます。

## SAMPLE-AESの復号

```ts
import { HlsClient } from 'mediaforgejs/streaming/hls';
import { createSampleAesHandler } from 'mediaforgejs/drm/sample-aes';

const client = new HlsClient({
    encryptionHandlers: [createSampleAesHandler()],
    fetch: (url, init) => fetch(url, { ...init, credentials: 'include' }),
});
await client.load('https://media.example/video.m3u8');
for await (const { data } of client.segments()) {
    // dataは復号済みの完全なTSまたはADTSリソース。
    await saveSegment(data);
}
```

`decryptSampleAesAac(frame, key, iv, signal?)`はADTSヘッダーを含む1フレーム、`decryptSampleAesAvc(nal, key, iv, signal?)`はスタートコードを除く1 NALを受け取ります。鍵とIVは各16バイトです。両関数とも入力を変更せず、所有権の独立したバイト列を返します。

## HLSからDRM再生へ接続

```ts
import { HlsClient } from 'mediaforgejs/streaming/hls';
import { createHlsDrmHandler, playHlsWithDrm } from 'mediaforgejs/streaming/hls-drm';
import { createHttpLicenseCallback } from 'mediaforgejs/drm/http-license';
import type { HlsDrmOptions } from 'mediaforgejs/streaming/hls-drm';

const drm: HlsDrmOptions = {
    keySystems: [{
        keySystem: 'com.widevine.alpha',
        license: createHttpLicenseCallback({
            url: 'https://license.example/widevine',
            headers: { Authorization: `Bearer ${token}` },
            credentials: 'include',
            maxResponseBytes: 1024 * 1024,
            timeoutMs: 10000,
        }),
    }],
};
const abort = new AbortController();
const client = new HlsClient({
    signal: abort.signal,
    adaptive: true,
    encryptionHandlers: [createHlsDrmHandler(drm)],
});
await client.load('https://media.example/master.m3u8');
await playHlsWithDrm(video, client.parts({ live: true }), {
    ...drm,
    signal: abort.signal,
    bufferAhead: 15,
    bufferBehind: 10,
    keyTimeoutMs: 15000,
    eme: { attachTimeoutMs: 10000, licenseTimeoutMs: 10000, maxSessions: 16 },
});
```

`keySystems`の設定順で、現在のKEYFORMATと対応能力が一致するCDMを選びます。対応能力の照会が`NotSupportedError`で拒否された場合だけ次候補へ進みます。証明書やライセンス取得の失敗は呼び出し元へ返します。暗号化された最初のデータをMSEへ追加する前にMediaKeysを接続し、ライセンス更新要求も同じコールバックへ渡します。完了は実際の`ended`まで待ちます。

| keySystem | 自動認識するKEYFORMAT | プレイリスト内の初期化データ |
| --- | --- | --- |
| `com.widevine.alpha` | `urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed` | base64 data URIのPSSH |
| `com.microsoft.playready`およびその派生名 | `com.microsoft.playready`、PlayReady UUID | PROをPSSHへ変換、UUID形式ではPSSH |
| `com.apple.fps` | `com.apple.streamingkeydelivery` | `skd:` URI |
| その他の設定名 | 同名、または明示した`keyFormats` | `getInitData`、またはブラウザーの`encrypted`イベント |

必要な証明書は各設定の`serverCertificate`へ渡します。ライセンスサービスがJSON、XML、独自ラップ形式を要求する場合は、`license(request)`で変換と通信を実装してください。HTTPヘルパーはバイナリPOSTとバイナリ応答用です。サービス固有の初期化形式は`getInitData({ keySystem, key, signal })`で`{ type, data }`を返します。`undefined`ならブラウザーの`encrypted`イベントを待ちます。これらのURIを通常のAES鍵として取得することはありません。

AVC/AACのCDM能力は`mimeType`またはvariantの`CODECS`から推定します。その他のコーデックやrobustness指定では`configurations`を明示します。再生中のCDM変更とcbcs/cenc間の変更はエラーにします。鍵の入れ替えは同一CDM内で新しい初期化データを登録します。セッションは再生終了まで保持し、`maxSessions`（既定8）を超えたら失敗します。長期の鍵ローテーションは、この上限とサービスのセッション更新方式を合わせて設定してください。

## 実サービス検証の設定

`node scripts/browser-ci.mjs --browser chrome --drm-service` は、環境変数 `MEDIAFORGE_DRM_SERVICE_JSON` を明示した場合だけ、指定された商用サービスで短いVODを再生します。公開デモサーバー、共通テスト鍵、ライセンスURLの既定値はありません。アカウント・コンテンツ・ブラウザー・runnerがサービス側の利用条件を満たすものを使用してください。CIの有効化と証拠の読み方は [BROWSER-CI-JA.md](BROWSER-CI-JA.md#認証済み商用drmサービスの任意ci) を参照してください。

以下は設定の形を示す例です。`example.invalid`、トークン、duration、codecは実際の認証済みサービスとテストコンテンツに置き換えます。この例自体に接続可能なサービスや鍵は含まれません。

```json
{
  "keySystem": "com.widevine.alpha",
  "manifestUrl": "https://media.example.invalid/protected/vod.m3u8",
  "mimeType": "video/mp4; codecs=\"avc1.64001f,mp4a.40.2\"",
  "expectedDurationSeconds": 12,
  "license": {
    "url": "https://license.example.invalid/widevine",
    "headers": { "Authorization": "Bearer REPLACE_WITH_SERVICE_TOKEN" },
    "credentials": "omit"
  },
  "media": {
    "allowedOrigins": ["https://media.example.invalid"],
    "headers": {},
    "credentials": "omit"
  },
  "minUsableKeys": 1,
  "minKeyChanges": 0
}
```

対象は2〜120秒、タイムラインが0から始まる、`EXT-X-ENDLIST`付きの単一メディアplaylistです。fMP4のSAMPLE-AES / SAMPLE-AES-CTRと、既存ブリッジが扱うKEYFORMAT・初期化データを使用します。master playlist、分離された複数renditionの同時再生、liveはこのsmokeの対象外です。単一トラックまたはmux済みのrenditionを指定します。期待durationはコンテンツ作成時の値を独立に入力します。

| 設定 | 条件 |
| --- | --- |
| `keySystem` | Chrome / Firefoxは`com.widevine.alpha`、Safariは`com.apple.fps`。ClearKeyを指定すると失敗 |
| `manifestUrl` / `license.url` | 認証済みのHTTPS URL。埋め込みユーザー名・パスワード・fragmentは禁止。signed queryはレポートに出さない |
| `license.headers` / `license.credentials` | サービスが必要とする認証。ヘルパーはバイナリchallengeのPOSTとバイナリlicense応答を扱う |
| `media.allowedOrigins` | playlist・MAP・segmentの取得先。省略時はmanifestのoriginだけ。認証はこの一覧内だけへ送る。redirectは失敗 |
| `certificateBase64` | FairPlayで必須の実サービス用証明書。DER bytesのbase64。Widevineでも必要なサービスなら指定可能 |
| `configurations` | 任意のEME能力配列。`initDataTypes`、`audioCapabilities`、`videoCapabilities`のcontentType・robustness・encryptionSchemeを指定。temporary sessionだけを使用 |
| `minUsableKeys` / `minKeyChanges` | usableになった異なる鍵IDの最低数と、取得区間のplaylist暗号情報変更の最低数。鍵入れ替え用素材では例えば2と1を指定 |
| `timeoutMs` | 全体の上限。既定はduration + 60秒、最大300秒。各HTTP / license / MSE操作にも上限あり |

Safariでは`keySystem`を`com.apple.fps`へ変更し、サービスから取得した`certificateBase64`を追加します。SDK同梱の開発用FairPlay資格情報は、実際の保護コンテンツ再生用の資格情報ではありません。JSON、SPC form、base64 CKCなど独自wire形式のサービスは、このバイナリ用smokeにそのまま接続できません。サービス管理者の認証済みバイナリエンドポイントを用意するか、契約仕様に従ってアプリ側の`EmeLicenseCallback`を実装してください。プロバイダーを推測する自動変換は行いません。

鍵変更のカウントはplaylist情報に基づき、鍵IDそのものは保存しません。2本のトラック用鍵が一度に供給されたことと、再生途中の鍵変更は異なるため、鍵ローテーションの確認には変更点が既知の専用素材と両方の最低数を指定します。現在のmacOS matrixはPlayReadyの実サービス検証を行いません。VMでの成功は、実機の出力保護や全サービスの認証を保証しません。

本実装では商用サービスへの接続成功をまだ取得していません。`prepared` / `skipped`、Node内の通信モデル、ClearKeyの結果は商用DRMの検証済み結果として扱いません。

一次資料: [Apple FairPlay Streaming](https://developer.apple.com/streaming/fps/) / [FairPlay開発用資格情報の範囲](https://developer.apple.com/library/archive/qa/qa1967/_index.html)（2026-09-25確認）。

## 鍵取得と任意方式の拡張

`HlsClientOptions.keyLoader(context)`を指定すると、標準の鍵HTTP取得を置き換えられます。独自URI、認証、別の鍵管理APIを利用できます。返却するのは`Uint8Array`です。AES-128と組み込みSAMPLE-AESでは16バイトを要求します。

```ts
const client = new HlsClient({
    keyLoader: async ({ key, signal }) => {
        const response = await fetch('/authorized-key', {
            method: 'POST',
            signal,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uri: key.uri }),
        });
        if (!response.ok) throw new Error(`Key request failed: ${response.status}`);
        return new Uint8Array(await response.arrayBuffer());
    },
    maxKeyBytes: 65536,
    maxCachedKeys: 8,
});
```

同時に有効なKEYFORMATは最大64種類です。鍵キャッシュはイテレーターごとに保持します。`maxCachedKeys: 0`で完了済みの鍵を再利用しません。同じURIの内容を変更する配信ではこれを指定するか、鍵のURIを変更してください。`loadKey()`はキャッシュの内容を変更できないよう独立したコピーを返します。外部コールバックの待機にも中止と`requestTimeoutMs`を適用します。利用側で大量のバイト列を確保する独自コールバックでは、その確保前の上限検査も利用側で行ってください。

`encryptionHandlers`は指定順に評価し、その後に組み込みAES-128を候補にします。各ハンドラーは`supports(context)`と`decrypt(request)`を実装します。リクエストには`key`、`kind`（map/segment/part）、`sequence`、`partIndex`、`uri`、`map`、`signal`、`data`、`loadKey()`があります。復号結果は`maxSegmentBytes`以下の`Uint8Array`で返します。認証タグの検証を含む、方式固有の処理はハンドラーの責任です。未登録の方式を平文扱いして通過させることはありません。

CDM向けのハンドラーだけが`retainsEncryption: true`を指定します。その出力は`unit.encryption`付きです。これを通常の平文データとして保存・変換する処理へ渡さないでください。`createHlsDrmHandler`と`playHlsWithDrm`を対にすると、この接続を自動化できます。

## EMEの追加設定と検証

`EmeController.attach`にも`serverCertificate`、`attachTimeoutMs`、`onKeyStatusesChange`、`keySystemAccess`を追加しました。最後の設定は照会済みの`MediaKeySystemAccess`を再利用します。`onKeyStatusesChange`へ渡すkey IDはコピーです。`configuration`の返却値を変更しても内部設定は変わりません。`attachTimeoutMs`は接続と`close()`の待機上限にも使い、遅れて完了するMediaKeys操作がある間は所有権を保持します。DRM再生の失敗・中止はネイティブ切断の完了を待たずに返し、遅れて完了する後始末を引き続き監視します。

通常のNode回帰テストでは、ソフトウェア復号を独立したAESベクトル、通信をHTTP、DRMの接続順と資源解放をEME/MSEモデルで確認します。FFmpegは不要です。実ブラウザーの連続再生、商用CDMと実ライセンスサービスの組み合わせは、上記CIを実行して結果を取得する必要があります。

形式の参照: [Apple SAMPLE-AES](https://developer.apple.com/library/archive/documentation/AudioVideo/Conceptual/HLS_Sample_Encryption/Encryption/Encryption.html)、[HLS RFC 8216](https://www.rfc-editor.org/rfc/rfc8216)、[Widevine HLS](https://developers.google.com/cast/docs/media/streaming_protocols)、[PlayReady HLS](https://learn.microsoft.com/en-us/playready/packaging/mp4-based-formats-supported-by-playready-clients)、[W3C EME](https://www.w3.org/TR/encrypted-media/)。
