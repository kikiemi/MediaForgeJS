# 対応範囲・設計・制限

## パケット経路

| 入力 | 索引化 |
| --- | --- |
| MP4/MOV/M4A/M4V/3GP、分割MP4 | 複数映像・音声、wvtt/stpp/tx3gなどの字幕、初期化セグメント |
| Matroska/WebM | 映像・音声・字幕、既存の章と添付ファイル保持 |
| MPEG-TS | 先頭programの対応映像1本・複数音声、ISO-639言語。最大64トラック |
| AVI、FLV | AVIはH.264設定・Bフレーム時刻の復元・PCM、FLVは対応AVC/AAC |
| ADTS AAC、MPEG Audio Layer I/II/III | 圧縮フレーム索引。設定変更、未対応のPCE/multiple raw blocksは拒否 |
| WAV/RF64、native FLAC、Ogg Opus/Vorbis | 整数8/16/24/32bit・浮動小数32/64bit・1〜32chのWAVE、FLACフレーム索引、単一Ogg論理ストリーム。詳細な制限はAPI-JA.md |
| AIFF/AIFC、AU、CAF | signed PCM8/16/24/32・float32/64、mono/stereo。AIFCはNONE/sowt/fl32/fl64/raw、CAFはpacked LPCMの対応部分集合 |
| その他 | 独自demuxerの明示登録。画像や再符号化は既存Converter経路 |

raw MP3索引はXing/LAMEのgapless trimを解釈せず、符号化済みフレームの時刻を返して警告します。読み出せる圧縮データに対して、復号実装を追加するものではありません。

| 出力経路 | 主な制約 |
| --- | --- |
| 通常MP4/MOV | standardは対応AVC/HEVC/AV1映像とAAC/AC3/EAC3音声。MOVは6種ProResとProRes RAW（aprn/aprh）のパケットコピーにも対応。MP4/M4A/M4Vのautoは必要時に分割MP4経路を選択（Opus/FLAC/ALAC/VP9・対応字幕等） |
| Matroska | 複数映像・複数音声、text/utf8・ASS/SSA・D_WEBVTT字幕。Engineの多重トラックはstandard出力。直接writerはfragmentedにも対応。整数PCM8/16/24/32・LE float32/64の対応配置、MPEG Audio Layer I/II/III、6種ProResもコピー可能 |
| WebM | VP8/VP9/AV1、Opus/Vorbis、D_WEBVTT。任意のMatroskaコーデックは許可しない |
| TS | 対応AVC/HEVC映像1本、AAC/AC3/EAC3/MPEG Audioの複数音声。合計64トラック以内。言語を保持し、表現できないname/title/default/forcedは警告 |
| AVI | AVC映像1本、PCM音声1本。圧縮音声をPCMとして書かない |
| FLV | AVC映像1本、AAC音声1本 |
| WAV/FLAC/Ogg | 対応音声1本のコピー。WAVは上記整数・浮動小数PCM、OggはOpus/Vorbis。RF64・priming/EOS trimを扱う |
| AIFF/AIFC・AU・CAF | 対応音声1本、mono/stereo、全bit有効。整数・floatのビット列を維持し、必要なendian/sign表現だけを変換 |
| raw AAC/MPEG | 一致する音声1本。ADTS書き出しはAAC-LC |
| CmafWriter/fMP4 | AVC/HEVC/AV1/VP9、AAC/Opus/FLAC/AC3/EAC3/ALAC、wvtt/stppの対応sample entry。複数映像・音声・字幕 |

AVI H.264はPOC 0/1/2、折り返し、参照Bフレーム、IDR/MMCO5、複数slice、MBAFFのフレームを扱います。1チャンクに完全な1フレームを持つ構成が対象です。別々のフィールド、複数画像を詰めたチャンク、未対応のpartition/extensionは拒否します。冒頭のIDRや参照履歴を欠く切断ファイルでは表示順を保証できません。

対応するコーデック名でも、必要な設定バイト・プロファイル・チャンネル配置・コンテナの表現範囲が必要です。`CodecRegistry.canMux`はファミリーの組合せ候補を示し、すべての設定で書けるという保証ではありません。外部形式へ再梱包するとコンテナ固有のメタデータを完全には保持できない場合があります。remux時の自動字幕形式変換、再生可能な任意位置編集、全タグの自動移植は行いません。

設定だけの照会には`MediaFile.checkRemux()`／`MediaJob.probe()`、全パケットとfinalizeまでの実処理検証には`await MediaFile.validateRemux()`／`await MediaJob.check()`を使用してください。

## コーデックの拡張

RegistryにはAVC/HEVC/AV1/VP8/VP9、AAC/Opus/Vorbis/FLAC/MPEG Audio/AC3/EAC3/PCM、字幕に加え、ALAC/DTS/VVC/Dolby Vision/ProRes/MPEG Videoなどの識別名があります。ALACはMP4入力とfMP4出力を実装しています。MOV・MKVへのProResコピーはapco/apcs/apcn/apch/ap4h/ap4xです。MKVはV_PRORESと4 byteのFourCCを扱います。標準のヘッダー省略ブロックを読み書きし、従来の完全ヘッダー付きブロックも読み込めます。プログレッシブ・フィールド順・8/16bit alpha・奇数寸法・色識別を検証しています。ProRes RAW、ProResの復号・符号化は含みません。DTS/VVC/Dolby Vision/MPEG Videoの識別は新しいエンコーダーやmuxerの実装を意味しません。独自辞書を登録でき、`probeNativeCodec`は完全な設定をホストのWebCodecsへ渡してその環境の対応を確認します。辞書とWebCodecs能力照会はFFmpegを自動実行しません。導入済みFFmpegには次の追加経路から明示的に接続します。

## 任意利用のFFmpeg経路

`runtime/ffmpeg`は導入済みFFmpeg/ffprobeによる単一ファイルの解析・変換・再梱包と、HLS/DASHのVODパッケージ出力です。`capabilities()`で実際の形式・コーデック名を取得します。MPEG-PS、MXF、NUT、CAF、ASFなども、導入されたdemuxer/muxer/codecの組合せに応じて扱えます。純粋なJavaScriptのパケット経路へ復号実装を追加したという意味ではありません。

Source入力は上限付き一時ファイル、Sink出力は対応するseek不要のmuxer、ファイル出力は成功確認後の置換を使います。HLS TS/fMP4とDASH fMP4の複数ファイル出力は`exportDirectory()`で、新しい専用ディレクトリーへ生成します。単一ファイルAPIへのHLS/DASH指定、連番画像、任意のfiltergraphやコマンド引数は含みません。詳細と実機確認範囲はRUNTIMES-JA.mdを参照してください。

## ストリーミングの境界

- HLSはmaster/media、rendition、map、byte range、discontinuity、live更新、AES-128 identityを扱います。`parts()`でPARTを取得・復号し、前のプレイリストを使ってSKIPを復元します。同一masterの整合した独立セグメントではopt-in ABRに対応。ライブではPDTまたは共有する不連続境界から時刻を対応付け、画質間のシーケンス番号の差を許容します。対応を確認できなければ警告して現在の画質を続行します。公開済みの非暗号化・AES-128 identity PARTも、時刻・不連続・独立境界が合えばABRで切り替えます。候補の取得・復号失敗や既知の欠落では現在の画質を維持します。SAMPLE-AESのAVC/AAC TS・ADTSは任意登録の暗号ハンドラーを使用します。blocking reload、date-range delta、別rendition同期は未対応です。
- `streaming/hls-playback`の`playHls()`はfMP4をMSEへ投入する任意利用の再生APIです。初期化、時刻原点、不連続、直列append、バッファ制限、中止を扱います。今回の実ブラウザー試験は実行環境の接続制限により未完了です。SourceBuffer代替による回帰試験、実HTTPでのHLS取得・復号、ネイティブ復号の結果とは区別します。ブラウザー・codecの組み合わせに対する実再生保証はしていません。
- 静的DASHはSegmentTemplate/Timeline/List、継承BaseURL、複数Period、整数tickとbyte rangeの参照計画を扱います。SegmentListの補助indexを保持し、SegmentBaseは`resolveDashManifest`で利用側提供のsidx bytesから解決します。動的MPD、階層sidx、xlink、暗号化ContentProtectionは拒否します。取得・再生・ABRは利用側が担当します。
- `readCmafSegments`は初期化データとmoof相対配置のmoof+mdatを逐次返します。progressive MP4、絶対オフセット、複数mdatにまたがる断片は対象外です。
- `CmafWriter`はCMAF向けに使える一般的な分割ISO BMFFを生成します。全プロファイルへのCMAF適合認証ではありません。Opusのprerollやgapless trimの再構築、暗号化は含みません。
- 分割出力では共通の原点で負のDTSを移動し、CTSを保持します。MatroskaのAAC/Opusは圧縮パケットの正確な長さへ復元し、元の時刻分解能1tick内の丸めだけを補正して警告します。実際の隙間は断片境界として残し、大きな重複は拒否します。
- `MediaFile.segments`のメディア断片は`independent`を返します。複数映像のキーフレームは必ずしも揃いません。`requireKeyframe:true`なら不適切な開始を拒否します。targetDurationは最大長・最大バイト数の保証ではありません。
- CmafWriterの標準保持上限は16 MiB・10万サンプル。直接writerを使う場合は上限前に利用側でflushし、エンジンのsegmentsは容量・件数に応じて自動flushします。`flushTo`はmoof・mdat・各サンプルをバックプレッシャー付きで書き、`flush`は連続配列を作ります。

- EMEはブラウザーの一時セッションとアプリ提供のlicense callbackを管理します。ClearKeyは明示的に与えたキーだけを応答します。商用DRMのCDM、ライセンスサーバー、暗号化ファイルのオフライン復号は提供しません。
- ASS/SSA・TTML/DFXP/IMSCはテキストとタイミングの読み書きです。完全な装飾描画、字幕焼き込み、IMSCの全プロファイル適合は含みません。

## 設計と計算量

新規利用の標準入口はWorkflowです。Source/Sink、トラック、圧縮パケット、診断を共通境界とし、OS固有のファイル処理をサブパスへ分離しました。Converter/Pipelineは形式・音声・画像・映像の部品をインスタンス単位で登録でき、既存入口は既定の組み合わせを提供します。

パケットの併合は、トラック数T・出力パケット数Pに対してO(P log T)、追加カーソルO(T)の最小ヒープです。既にあるトラック索引を全件展開して毎回ソートしません。元のDTS索引が未整列なら、そのトラックだけ初回に並べ替えます。PTSが整列済みで全サンプルが検索対象なら、検索用配列の作成・ソートを省き、初回からO(log P)で検索します。キーフレーム抽出だけが必要ならO(P)の索引を初回だけ作り、PTS未整列の場合だけO(P log P)のソートを行います。以降の検索は二分探索です。対応する通常MP4はサイズ・位置を数値配列、時刻を連続区間として保持し、各サンプルのオブジェクト化を遅延します。初期のO(P)検証と数値表は残り、すべての形式が逐次索引になる変更ではありません。

`packets({keyframesOnly:true})`はDTS順のキーフレーム索引を初回だけ作り、繰り返し抽出で非キーフレームを走査しません。以後は対象トラックの二分探索と、選択されたキーフレーム数に比例する併合になります。

Sourceの合成は既存の構造共有木、読み取りは上限付きLRUページキャッシュを使用します。連続する未取得ページを、1回につき最大1 MiB・64ページ・保持上限の範囲でまとめて取得します。既存の取得中ページとキャッシュを越えて重複取得せず、無効化前の処理が新世代のキャッシュを上書きしません。Subtitleの重なりは時刻イベントをソートして走査します。出力すべきCue自体が多数重なる場合、その出力サイズ相応の処理は必要です。

変換アダプターはエンジン所有の索引を共有し、全サンプルの重複オブジェクト化を避けます。`MediaFile.close()`は入力・索引の内部参照を解放します。再符号化もSourceから必要な範囲だけを読みます。形式ごとの初期索引走査・保持、standard MP4の出力索引、Blob出力の全量保持は残ります。100GB級のSourceを扱えても、全経路のconstant-memoryを保証するものではありません。

## 検証と配布

実データによる外部FFmpeg/ffprobeとの往復、独立したボックス・オフセット検査、HTTPとOS入出力、TypeScript公開型、既存ブラウザー経路で検証します。Bun/Denoの実機確認範囲はRUNTIMES-JA.mdを参照してください。

ソースZIPにはsrc・dist・ビルド設定・公開資料・ライセンス・分割した回帰テスト・独自素材の生成器・実ブラウザーCI設定を含めます。npmの利用用パッケージは実行ファイル・型・公開資料・ライセンスに限定します。第三者のテスト素材や生成済みの大量メディアは同梱しません。すべての不正ファイルや実行環境に対して不具合がないことを保証するものではありません。

破損入力の回復範囲と実ファイル検証は[回復と検証](RECOVERY-JA.md)を参照してください。

## 任意のProResコーデック

`mediaforgejs-prores`は通常ProResの6プロファイルを復号し、RGBA8入力から符号化します。`mediaforgejs-prores-raw`はProRes RAWをlinear 16bit RGGB Bayerへ復号します。RAWの現像・エンコード、全カメラ独自メタデータの解釈は含みません。[具体的な入力制約](PRORES-JA.md)を参照してください。

5.4.0ではMP4の入力・出力索引を圧縮し、ProResの閉じたハンドルの参照保持を修正しました。[メモリ使用量](MEMORY-JA.md)と[実測・未検証範囲](VERIFICATION-JA.md)を参照してください。索引・Blob・非seekable標準MP4の全量保持は一律にはなくなっていません。
