# 4.0への移行

## FlowCast

通常のESM入口は`MediaForgeConverter`と`MediaForgeError`を公開します。旧名が必要な既存コードでは入口を変更してください。

```ts
import { FlowCastConverter, FlowCastError } from 'mediaforgejs/compat/flowcast';
```

ブラウザーの通常バンドルが作る名前は`MediaForgeJS`と`MediaForgeJSReady`です。通知は`mediaforgejs:ready`です。旧名を使うページでは、通常バンドルの後で`dist/compat/flowcast.global.js`を読み込みます。この追加スクリプトだけが`FlowCast`・`FlowCastReady`・`flowcast:ready`を提供します。

旧名のオブジェクトは通常APIを変更しません。`FlowCast.noConflict()`は旧名の2変数だけを復元し、`MediaForgeJS.noConflict()`は通常名の2変数を復元します。読み込み後に別のコードが置き換えた変数は復元対象にしません。以前のプロパティ記述子も保持します。複数回読み込んだ場合は逆順に復元してください。

ビルド出力先は`MEDIAFORGE_DIST_DIR`で指定します。`FLOWCAST_DIST_DIR`は使用しません。

## 機能別の入口

既存の正規サブパスは維持します。まとめて選択する場合は`audio`・`demux`・`mux`・`streaming`・`drm`を使えます。最小構成には従来の個別サブパスや`engine/core`・`converter/core`・`pipeline/core`を使用してください。

`workflow`はSource/Sinkを使う高水準の入口です。`workflow/core`は形式と音声処理を明示的に登録し、`workflow/audio-pcm`と`workflow/audio`でPCM出力または追加の自前音声エンコーダーを選べます。FFmpegは必須ではありません。ブラウザーのネイティブコーデックやDRMの対応は実行環境によって異なります。

`strict`は構造検証、`metadataPolicy`は出力に保持できないメタデータの扱いを指定します。この役割分担とTrackUIDのBigInt保存方式は変更しません。

## インストールと公開

この配布版のnpmレジストリへの公開は未完了です。同梱したtarballは次のようにインストールできます。

```sh
npm install ./release/mediaforgejs-4.0.0.tgz
npm install ./release/mediaforgejs-4.0.0.tgz ./release/mediaforgejs-streaming-4.0.0.tgz
```

拡張は`mediaforgejs-streaming`・`mediaforgejs-audio`・`mediaforgejs-drm`・`mediaforgejs-ffmpeg`です。本体をpeer dependencyとして共有する入口パッケージであり、同じ実装を複製しません。本体のディスク容量を分割するものではありません。読み込む実行コードはサブパスにより選択できます。

FFmpeg拡張だけは利用側のFFmpeg/ffprobeを必要とします。本体・他の拡張から自動的に読み込むことはありません。

公開準備と検証の手順は[RELEASING-JA.md](RELEASING-JA.md)を参照してください。
