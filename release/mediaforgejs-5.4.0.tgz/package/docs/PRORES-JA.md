# ProRes・ProRes RAW

通常のProResとProRes RAWは別のビットストリームです。本体は圧縮パケットの読み書きを担当し、復号・符号化は必要な拡張だけを追加します。FFmpeg実行ファイルの起動やWebCodecsグローバルの置き換えは行いません。

| 機能 | 範囲 |
| --- | --- |
| 通常ProResのコピー | apco/apcs/apcn/apch/ap4h/ap4x。MOVとMKV間で圧縮データを保持 |
| 通常ProResの復号 | 任意WASM拡張。10/12bit planar YUV、progressive/interlaced、8/16bit alpha |
| 通常ProResの符号化 | 任意WASM拡張。6プロファイル、progressive、BT.709のRGBA8入力 |
| 透過の符号化 | ap4h/ap4x。422系のプロファイルへ透明画素を渡すと拒否 |
| RAWのコピー | aprn/aprh、standard MOV。通常ProResのMKV形式へ流用しない |
| RAWの復号 | 任意JavaScript拡張。version 0/1のRGGBを16bit linear Bayerへ復号 |

## Workflowへ追加する

この配布物は未公開のため、まず同梱tarballを利用します。ProRes拡張のWASM依存はnpmから取得します。

```sh
npm install ./release/mediaforgejs-5.4.0.tgz ./release/mediaforgejs-prores-5.4.0.tgz
```

```ts
import { MediaWorkflow } from 'mediaforgejs/workflow/core';
import { createVideoTransform } from 'mediaforgejs/workflow/video';
import { mp4 } from 'mediaforgejs/engine/formats/mp4';
import { matroska } from 'mediaforgejs/engine/formats/matroska';
import { proResVideoCodec } from 'mediaforgejs-prores';

const formats = [mp4, matroska];
const workflow = new MediaWorkflow({
    formats,
    transform: createVideoTransform({ formats, codecs: [proResVideoCodec] }),
});

const request = {
    operation: 'convert', format: 'mov', videoCodec: 'ap4h',
    allowPrecisionLoss: true,
} as const;
const result = await workflow.toBlob(input, request);
```

`allowPrecisionLoss:true`は高bit深度からRGBA8への量子化を許可します。RGBA8から作るProResを10/12bit素材と同じ精度とは扱いません。精度を保って形式だけ変える場合は`remux`を使用してください。

登録コーデックとWebCodecsを片側ずつ組み合わせることもできます。ホストの復号・符号化能力は実行時に確認します。追加コーデックの変換経路は映像1本を処理し、互換な音声・字幕をコピーします。`trackIds`で映像を選択できます。リサイズ、fps変更、同時の音声再符号化、HDR現像、interlacedからprogressiveへの変換など、実装していない処理は明示的に拒否します。コピーだけなら従来の複数映像経路を利用できます。

`check()`は実際の復号・符号化と出力のfinalizeまで行います。通常の出力に必須ではなく、事前確認後に本出力すれば処理は2回になります。

## パケットを直接復号・符号化する

`mediaforgejs-prores`の`createProResDecoder`と`createProResEncoder`はパケット単位のAPIです。時間は秒単位で統一しています。`decode()`が返すフレームは呼び出し側が所有し、使い終わったら`close()`します。デコーダーを閉じても返却済みのフレームは有効です。

16bit alphaは専用の`I444P12A16`等の形式で保持します。この形式をWebCodecsの12bit alpha形式として誤って渡さないでください。`toRGBA({allowPrecisionLoss:true})`はSDR用の簡易変換で、HDR tone mappingや色域変換ではありません。未指定の色行列をBT.709と仮定した場合は`colorSpaceAssumed`で確認できます。

`encode()`はstraight alphaのRGBA8を受け取り、独立したProResパケットを返します。中間MOVを作らず、出力の全フレーム索引も蓄積しません。`await`で1件ずつ渡すと自然に流量を制限できます。同時要求は`maxQueueSize`（既定4件）までで、超過時は入力を保持せず拒否します。

WASMの同期処理はフレームの途中では中断できません。キャンセルは処理の境界で確認し、終了処理は実行中のフレームが終わってから資源を解放します。詳細な設定・所有権・ライセンスは拡張のREADMEを参照してください。

## ProRes RAW

```sh
npm install ./release/mediaforgejs-prores-raw-5.4.0.tgz
```

```ts
import { decodeProResRawAsync } from 'mediaforgejs-prores-raw';

const frame = await decodeProResRawAsync(packet.data, {
    codec: 'aprn', signal, tilesPerYield: 32,
});
// frame.dataはUint16Array。strideはbyte数ではなく行あたりの要素数。
consumeBayer(frame.data, frame.width, frame.height, frame.stride, frame.color);
```

出力はセンサーのBayerデータです。線形化は適用しますが、黒レベル補正、白バランス、demosaic、camera-to-XYZ変換、gain、推奨cropは適用しません。これらに必要な情報は`color`と`recommendedCrop`から取得します。RAW encodeとカメラ専用ISPは含みません。

独自の合成パケットを参照C実装と照合しています。カメラ実写素材、各メーカーの現像器、すべての独自メタデータとの互換性は未検証です。パケット上限・画素上限・タイル上限を出力配列の確保前に検査します。

## メモリとライセンス

追加コーデックはキュー・パケット・画素数で保持量を制限します。メモリは画像寸法に比例し、呼び出し側がフレームを保存し続ければその分増えます。Workflowの入力全体のBlob化は不要になりましたが、コンテナの索引やstandard MP4出力、Blob出力の保持は残ります。全経路のconstant-memory保証ではありません。

通常ProResはTurboRes（MPL-2.0）とprores-wasm-encoder（LGPL-2.1-or-later）を使用します。後者と16bit alphaの補助処理にはFFmpeg由来のコードが含まれます。RAW拡張もLGPL-2.1-or-laterです。本体のWTFPLへ変更せず、各拡張のライセンス・NOTICE・編集可能なソースを同梱します。

## オフラインとメモリ

通常ProResの依存にはWASM本体が組み込まれており、復号・符号化時にCDNからWASMを取得しません。npm依存を空キャッシュへオフライン導入する場合は、拡張tarballだけでなく[オフライン配布一式](OFFLINE-JA.md)を使用してください。

Nodeでは、閉じたラッパーを利用側が保持していてもネイティブインスタンスへの参照を外します。返されたフレームを閉じ、利用側が取得したプレーンやRGBA配列の参照も不要になった時点で外してください。WASMは使用中の高水位までメモリを確保するため、画素数や透過の有無で必要量が大きく異なります。

TurboResはブラウザーで共有ランタイムをキャッシュするため、Nodeでの解放結果をブラウザーに当てはめることはできません。実ブラウザーの長時間・高解像度処理は別途検証が必要です。今回の実測条件は[検証結果](VERIFICATION-JA.md)に記載します。
