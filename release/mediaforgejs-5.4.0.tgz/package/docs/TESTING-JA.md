# テスト

```sh
npm run build
npm test
node --test test/ts-multiaudio.mjs
```

`scripts/run-tests.mjs`は分野別の試験を別プロセスで実行します。標準試験はNodeだけで動き、FFmpeg・外部サービス・ダウンロード素材に依存しません。`helpers/original-fixtures.mjs`などでコンテナを独立生成し、ProRes/H.264の固定符号化フレームも独自に生成した画像を使います。必要に応じて製品のdemuxerとは別の小さな構造読取器で出力を検査します。

| 試験 | 内容 |
| --- | --- |
| `ts-multiaudio.mjs`, `ts-legacy.mjs` | 多音声のPID・設定・時刻・言語・payload、分割PMT、索引予算、旧API |
| `avi-h264.mjs` | AVI設定・NAL境界、POC 0/1/2・折り返し・リセット、open/closed GOP、PTS/DTS・表示順 |
| `mp4-preservation.mjs`, `mp4-title-interop.mjs` | 映画・トラックのtitle/name/default、独立したbox検査 |
| `prores-matroska.mjs`, `multitrack-pcm.mjs` | ProRes各profile、標準MKVブロック、フィールド・alpha・奇数寸法・破損、PCM、多映像・多音声 |
| `matroska-mpeg-audio.mjs`, `audio-clock-precision.mjs` | MPEG音声のコピー、PCM/MPEGの時刻丸め、実際の隙間・重複の拒否 |
| `pipeline-copy-codecs.mjs` | コピー時のコーデック・サンプルレート、多音声、ProRes映像とAAC変換の組合せ |
| `matroska-video-codecs.mjs` | AVC/HEVC/AV1/VP9のcodec識別、ページ境界・lacing・中止 |
| `webcodecs-video.mjs`, `webcodecs-audio.mjs` | コーデック設定、フレーム長、非有限PCM、並べ替え、非同期失敗、中止、資源解放。Node上の契約試験 |
| `workflow*.mjs`, `remux-validation.mjs` | 公開API、同一要求の検証と出力、所有権、中止、上限、選択構成 |
| `media-file-lifetime.mjs` | close後のAPI動作と借用Sourceの所有権 |
| `corpus.mjs`, `demux-stress.mjs` | 形式横断の独自素材、破損・境界・資源予算 |
| `smoke.mjs` | `suites/`の既存機能別回帰 |
| `browser/harness.test.mjs` | ブラウザー試験ハーネス自体。実ブラウザーの検証とは別 |

性能は通常のテストに不安定な秒数しきい値を設けず、比較用コマンドで測ります。

```sh
node test/bench-ts.mjs --baseline /path/to/previous/dist --rounds 5
node test/bench-demux.mjs --baseline /path/to/previous/dist --rounds 5
node test/bench-workflow.mjs --baseline /path/to/previous/dist --rounds 5
```

素材、対象処理、Node版、反復数、raw観測値と中央値を記録します。速度は入力・出力先・実行環境で変わります。1 ms周期のメモリ観測は同期処理中の真のピークを保証しません。通常のnpm tarballにはテスト、作業ログ、生成用資料を含めません。

## 任意の映像コーデック

`npm run test:codecs`でProResの実WASM復号・符号化、RAWのBayer復号、Workflowへの接続を検証します。`npm run check`はこのグループも実行します。`npm test`は共通本体の機能試験です。codec用依存は`npm ci`で取得し、試験実行中の外部メディア取得やFFmpeg起動は不要です。独自の画素・圧縮パケットと参照実装から得た期待値を使います。

100GBのSource検証は、疎なmdatと64bitオフセットを持つ仮想入力で行います。100GBの実写動画を全経路で処理した結果ではありません。別のコンテナ、長時間の全索引保持、利用側が保存するBlobやフレームの容量までは保証しません。

## 配布物と任意資料

利用用npm tarballには実行コード・型・公開API資料・ライセンスを含め、テスト・素材・CI・作業ログ・AI用設定は含めません。ソースZIPの通常の機能テストとCIは再ビルド・保守用です。私的な性能測定スクリプトや作業計画はソースZIPにも含めません。

`CHANGELOG-JA.md`は削除しても実行・ビルド・テスト・release検証に影響しません。記述規則を指示する独立文書やAI用設定は不要です。書式検査を使わない場合は`prettier.config.mjs`を削除します。この場合`format`/`format:check`は明示的にスキップを表示し、型検査・機能テストは継続します。
