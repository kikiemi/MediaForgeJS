# パケット・字幕・メタデータAPI

## パケットエンジン

`new MediaEngine().open(Source | Blob | ArrayBuffer | ArrayBufferView, options)`は`MediaFile`を返します。読み取り中はSourceのサイズと内容を固定してください。入力バイト配列は標準でコピーされます。

```ts
import { MediaEngine, type Source } from 'mediaforgejs';

export async function inspect(source: Source): Promise<void> {
    const file = await new MediaEngine().open(source, { maxPacketBytes: 32 * 1024 * 1024 });
    try {
        const video = file.tracks.find(track => track.type === 'video');
        if (!video) return;
        const index = file.findSample(video.id, 10, { keyframe: true, mode: 'before' });
        if (index !== undefined) console.log(await file.readPacket(video.id, index));
        for await (const packet of file.packets({ trackIds: [video.id], start: 10, end: 12 })) {
            console.log(packet.trackId, packet.timestamp, packet.data.byteLength);
        }
    } finally { file.close(); }
}
```

- `tracks`: ファイル内のID、種類、コーデック、寸法、サンプルレート、言語、時間、サンプル数、回復されたトラックの`incomplete`表示。返却した設定バイトを変更しても内部には影響しません。書き出し先のコンテナではIDが振り直される場合があります。
- `readPacket(trackId, sampleIndex, signal?)`: 独立したバイト列を返します。`timestamp`はPTS、`decodeTimestamp`はDTS、`duration`は秒です。`codecConfig`は該当サンプルの設定です。
- `packets(options?)`: 選択したトラックをDTS順にマージするAsyncGenerator。`start`は含み、`end`は含まないDTS範囲です。時刻による読み出しは編集・キーフレームの前読み・再生可能な切り出しを意味しません。
- `findSample(id,time,{keyframe,mode})`: PTSによる検索。標準は`keyframe:false, mode:'before'`。前後に候補がなければ`undefined`。時刻が完全一致する場合は、その時刻で最初の該当サンプルを返します。整列済みPTSは追加の全件索引を作らず二分探索します。
- `remux(sink,{format,trackIds?,signal?,onProgress?})`: 再圧縮なしで書き出します。通常出力の進捗は`packets`と`packetBytes`で、コンテナ込みの出力サイズではありません。fMP4出力も同じパケット件数・圧縮パケットバイト数を通知します。コンテナを含む各断片のサイズは`segments()`で取得します。
- `toBlob({format,maxBytes?})`: メモリーへ書き出します。標準の上限は256 MiB。
- `segments({targetDuration?,maxBufferedBytes?,maxBufferedSamples?,requireKeyframe?,signal?})`: 初期化セグメント、続いてメディアセグメントを返します。目標長は標準2秒ですがキーフレーム間隔や実際の不連続に依存します。容量・サンプル数の上限に達する前にも断片を確定し、全体の処理を継続します。単一パケットが容量上限を超える場合は失敗します。詳細はSTREAMING-JA.md。
- `close()`: 自身の待機を中止し、索引・圧縮データ・入力Source・キャッシュへの内部参照を解放します。借用Sourceは閉じません。トラックの説明情報は参照できますが、読み込み・検索・出力は`ABORT`で失敗します。

`open`の標準制限は1パケット64 MiB、索引200万サンプル、128トラックです。`cacheBytes`は保持する入力ページの上限で標準4 MiB、`readPageBytes`は標準64 KiB、`cacheBytes:0`は保持を無効にします。`maxSamples`は組み込みdemuxerへ伝わる合計件数の上限です。`maxIndexBytes`は推定索引容量の上限で標準128 MiB。両方を満たす必要があります。組み込みエンジンの対応する通常MP4では数値表の保持量を計上し、サイズ・位置は主に12 byte/サンプル、時刻は連続区間の表を保持します。遅延作成する検索・整列索引も予算に計上します。互換経路と低水準demuxerの展開済み索引はclassicが256 byte/サンプル、fragmentが640 byte/サンプルの推定です。上限超過は`OOM`、不正設定は`FORMAT`です。これは実測ヒープ、入力キャッシュ、圧縮ペイロードの上限ではありません。形式の構造・ヘッダー・ペイロードには別の制限が残ります。対応する通常MP4はサンプルオブジェクトを必要時だけ作りますが、初期の表走査・全サンプルの範囲検証は残ります。cslgや分割MP4などは従来の展開経路です。低水準`MP4Demuxer`の`samples`配列契約は維持しています。

新規利用の標準APIと選択構成は[Workflow](WORKFLOW-JA.md)を参照してください。

独自形式は`registerDemuxer({formats,demux})`で登録し、`open(source,{format:'独自名'})`で選択します。結果は公開`MP4DemuxResult`構造に従い、各サンプルにSource内の範囲または`data`を指定します。未知形式を自動判定するプラグイン機構や独自コーデックの実装を暗黙に提供するものではありません。

### 音声ファイルの再梱包

WAV/RF64・AIFF/AIFC・AU・CAFの整数PCM・IEEE浮動小数、native FLAC、単一論理ストリームのOgg Opus/Vorbisを`open()`で索引化できます。`remux()`の`wav`・`aiff`・`au`・`caf`・`flac`・`ogg`は対応する音声1トラックを再圧縮せずに書き出します。元の形式と別のコーデックへ変換する場合はWorkflowを使用します。

```ts
import { MediaEngine, type Source, type Sink } from 'mediaforgejs';

export async function copyOgg(source: Source, output: Sink): Promise<void> {
    const file = await new MediaEngine().open(source);
    try { await file.remux(output, { format: 'ogg' }); }
    finally { file.close(); }
}
```

`demuxStandaloneAudio`は低水準の同じ索引APIです。直接呼ぶ場合の`maxPacketBytes`は標準16 MiB・最大64 MiB、エンジン経由では`open()`の標準64 MiBを使います。Ogg Opusはmapping family 0 mono/stereo、Vorbisは1〜8チャンネルです。多重化・連結Ogg、未知の初期granuleオフセットは明示的に拒否します。ページをまたぐOggパケットの再構成保持量は合計64 MiBまでです。FLACの最大フレーム長がSTREAMINFOで不明なら4 MiBを上限に走査します。

WAVEは整数8/16/24/32bit、浮動小数32/64bit、1〜32チャンネル、1〜768000 Hzのinterleaved形式です。16bit以上はlittle-endian、8bit整数はunsignedです。フレーム境界に整列したdataチャンク1個を扱い、空のPCMも索引化できます。RIFX、圧縮WAVE、分散した複数dataチャンクは未対応です。

| トラックのcodec | 格納形式 |
| --- | --- |
| `pcm` | 有効16bit、標準または未指定配置のmono/stereo整数PCM |
| `pcm-s16le` | 有効bit数が少ない、複数ch、または非標準配置の整数PCM16 |
| `pcm-u8`, `pcm-s24le`, `pcm-s32le` | 各幅の整数PCM |
| `pcm-f32le`, `pcm-f64le` | IEEE浮動小数 |

WAVEトラックの`codecConfig`はfmt payloadです。`parseWaveFormat(track.codecConfig)`で`bitsPerSample`、`validBitsPerSample`、`channelMask`、`blockAlign`などを確認できます。WAVEFORMATEXTENSIBLEの有効bit数と32bitスピーカーマスクはコピー出力で保持し、マスクが未指定ならチャンネル配置を推測しません。整数の有効bitは格納幅の上位側です。これらのパケットAPIは数値変換を行わず、既存PCM16エンコーダーの対応範囲を変更しません。

AIFF/AIFCとAUはmono/stereo、1〜768000 Hz、全bit有効の整数8/16/24/32bit・float32/64bitを扱います。`aiff`はFORM AIFF/AIFC、`au`は`.snd`から自動判定します。AIFF整数とAUはbig-endian・signed8です。AIFC入力はNONE/twos/in24/in32・sowt・fl32/fl64（大文字を含む）・rawの対応部分集合です。圧縮AIFC・AU μ-law/A-lawの復号はこの経路に含みません。

CAFは`caff` version 1、先頭の`desc`、単一`data`のpacked LPCMを扱います。整数はsigned、16bit以上はbig/little-endian、floatは32/64bitです。入力の既知長と終端`data`の未知長`-1`、標準mono/stereoの`chan`、trimなしの整合した固定`pakt`を扱います。出力はsigned8またはlittle-endianで、64bitのchunk長を持ちます。CAFのALAC/AAC、圧縮コーデック固有情報、planar PCM、可変packet、任意スピーカー配置はこの純JavaScript経路には含みません。空PCMも入力・コピーできます。 [Apple CAF仕様](https://developer.apple.com/library/archive/documentation/MusicAudio/Reference/CAFSpec/CAF_spec/CAF_spec.html)。

| 追加のcodec | 格納形式 |
| --- | --- |
| `pcm-s8` | signed8 |
| `pcm-s16be`, `pcm-s24be`, `pcm-s32be` | signed big-endian整数 |
| `pcm-f32be`, `pcm-f64be` | big-endian IEEE浮動小数 |

`remux({format:'wav'|'aiff'|'au'|'caf'})`はサンプルの数値を変えず、必要なバイト反転と8bitの符号バイアスだけを変更します。AIFFへのfloat出力はAIFCになります。WAVE由来の少ない有効bit数・非標準配置・多チャンネルを表現できない別形式へ書く場合は、最初のwrite前に拒否します。WAVE→WAVEでは既存の精度・配置情報を保持します。`CodecRegistry.resolve('twos')`はbig-endianの`pcm-s16be`を返します。

AIFFの32bit FORM長・frame数の上限は検証してから出力します。AUは大きい出力に未知長のsentinelを使います。SSND offset・偶数境界のpadding、AUの注釈領域と未知長を扱い、宣言範囲の外の余剰バイトなど、回復可能な条件はcompatibleで警告します。必須ヘッダー・精度・フレーム数の不一致や、途中で切れたPCMフレームは拒否します。AUの明示長0x80000000〜0xfffffffeはこの経路では対象外で、2 GiB以上の出力には未知長0xffffffffを用います。サンプル索引は基本4096フレームを1パケットにまとめ、全PCMを保持してから書く構成にはしません。


Vorbisは`VorbisMuxer`、Opusは既存の`OGGMuxer`で直接書けます。Ogg同士のコピーではprimingと最終granuleによる末尾切り詰めを保持します。WAVは出力サイズを索引から先に算出してRIFF/RF64ヘッダーを書き、PCM全体を保持しません。コンテナの任意コメントや画像タグの全自動移植は含みません。

## 寛容な入力と警告

パケットエンジン・HLS・DASH・字幕の標準は`validation:'compatible'`です。逐次MP4入力の`iterateMp4Boxes`・`readCmafSegments`は標準`'strict'`で、末尾回復には`'compatible'`を明示します。`onWarning`と`warnings`、テキスト・メタデータの`diagnostics`で回復内容を確認できます。`validation:'strict'`は回復を伴う構造問題をエラーにします。タグ・言語・トラック属性の保持制限、境界が確認できる任意メタデータの不正値は、`metadataPolicy:'warn'`（既定）ならstrictでも警告して続行します。完成MP4の不要な任意末尾も警告です。透過や音声の提示範囲などメディア内容が変わる損失、I/O失敗、中止はこの対象ではありません。既存の低水準demuxerの既定動作は維持しています。

`MediaEngine.open`では構造検証と情報保持を独立して選べます。

| 設定 | 回復可能なメディア構造の問題 | 検出した任意メタデータの損失 |
| --- | --- | --- |
| `validation:'compatible', metadataPolicy:'warn'`（既定） | 警告して回復 | 警告して続行 |
| `validation:'strict', metadataPolicy:'warn'` | 拒否 | 警告して続行 |
| `validation:'compatible', metadataPolicy:'error'` | 警告して回復 | `FORMAT`で拒否 |
| `validation:'strict', metadataPolicy:'error'` | 拒否 | `FORMAT`で拒否 |

3.7.1のように任意情報の損失でも停止したい利用側は、`metadataPolicy:'error'`を明示してください。これは全警告をエラーへ変える設定ではありません。保持不能を検出した出力では、`checkRemux()`が`supported:false`と診断を返し、実出力も書き込み前に拒否します。事前チェックは警告コールバックを呼びません。`maxWarnings:0`で通知を抑制しても保持必須条件は無効になりません。

回復するのは、例えば完全なMP4の後ろにある壊れた任意ボックス、字幕の安全に解釈できる表記、HLSの既知の軽微な書式問題、完全なフレームが先行し、ヘッダーで必要な長さを確認できるADTS/MPEG音声の不完全な最終フレームです。未知の末尾データを一律に捨てる動作ではありません。必須ボックス、サンプルの範囲、危険な整数、必要なコーデック設定、暗号化を推測で修復しません。破損した圧縮フレームそのものの誤り訂正も行いません。`maxWarnings`は標準100、0〜10000で、上限後の通知は抑制されます。

## 字幕

3.12.0では時刻補正・区間切り出し用の`editSubtitles`を追加しました。[使用例と埋め込み時刻の制限](3.12.0-FEATURES-JA.md#字幕の切り出しと時刻補正)を参照してください。

```ts
import { parseSrt, writeWebVtt, parseWebVtt, toSubtitleChunks, CmafWriter } from 'mediaforgejs';

const document = parseSrt('1\n00:00:01,000 --> 00:00:02,500\nこんにちは\n');
const webvtt = writeWebVtt(document);
const parsed = parseWebVtt(webvtt);
const writer = new CmafWriter({ tracks: [{ id: 1, type: 'subtitle', codec: 'wvtt', timescale: 1000 }] });
const init = writer.createInitSegment();
for (const chunk of toSubtitleChunks(parsed, 'wvtt')) writer.addChunk(1, chunk);
const segment = writer.flush();
console.log(init.byteLength, segment.data.byteLength);
```

Cueの`startTime/endTime`は秒。WebVTTのID・settings・NOTE/STYLE/REGION・ヘッダーとtimestamp mapを保持します。fMP4への変換では重なるCueを有効区間で分割し、空白区間を`vtte`にします。`encodeWebVttSample/decodeWebVttSample`は`vttc/vtte`、`encodeWebVttBlock/decodeWebVttBlock`はWebMのD_WEBVTTペイロードを扱います。S_TEXT/WEBVTTとは構造が異なるため、両者の暗黙変換は行いません。

`parseSubtitles`は形式判定または明示指定を行い、`writeSubtitles`は指定形式へ変換します。`parseAss/writeAss`と`parseTtml/writeTtml`も直接利用できます。

```ts
import { parseSubtitles, writeSubtitles } from 'mediaforgejs';

export function subtitleToTtml(input: Uint8Array): string {
    const document = parseSubtitles(input, {
        validation: 'compatible',
        onWarning: warning => console.warn(warning.code, warning.message),
    });
    return writeSubtitles(document, 'ttml', {
        onWarning: warning => console.warn(warning.code, warning.message),
    });
}
```

ASS/SSAはフィールド順、スタイル、Script Info、overrideの原文を保持し、Cueの`text`は表示用の平文です。平文を編集したCueでは古いoverrideをそのまま再使用しません。バイト入力はBOM・明示的`encoding`に対応し、ASSの1/100秒への丸めは診断を返します。

TTMLは名前空間、style参照、region、span、言語、時刻の継承とclip、body/divの順次タイミングを扱います。`dfxp`・`imsc`指定はTTMLテキスト部分集合の別名です。frame/subframe/tick時刻に対応しますが、media以外のtimeBaseは拒否し、時刻付きspanの平文化や保持できない装飾は警告します。XML外部参照・DTD・カスタムentityは処理しません。XMLの標準上限は深さ64、要素・属性・テキストを合計200000個です。

TTMLへ書き出す際、SRTの数字だけのIDなどXML IDとして不適切な値や重複IDは、一意なIDへ変更して`SUBTITLE_ID_LOSS`を通知します。本文とタイミングは保持します。

MP4ではwvtt、stpp、tx3gなどの字幕トラックを索引化します。TTMLやASSの描画エンジン、焼き込み、CEA字幕復号は含みません。テキスト形式ごとに表現できない装飾は警告の対象です。

## メタデータ

```ts
import { createId3Tag, writeId3Tag, parseId3Tag, encodeEventMessage, decodeEventMessage } from 'mediaforgejs';

const tag = createId3Tag({
    entries: [{ key: 'title', value: { type: 'text', value: '日本語タイトル' } }],
    chapters: [{ id: 'chapter-1', startTime: 0, endTime: 20, title: '開始' }],
});
const bytes = writeId3Tag(tag);
console.log(parseId3Tag(bytes));
const event = encodeEventMessage({ version: 1, timescale: 1000, presentationTime: 12500n,
    eventDuration: 500, id: 1, schemeIdUri: 'urn:example:event', value: '',
    messageData: new TextEncoder().encode('event') });
console.log(decodeEventMessage(event));
```

`normalizeMetadata`は文字列、整数bigint、数値、真偽値、日付、バイナリー、言語、章を正規化します。ID3 v2.3/v2.4は未知フレームを保持し、対応しないタグ全体の構造はopaqueとして警告付きで保持します。`Id3Tag.metadata`は読み取り用の投影です。変更して書き直す場合は`createId3Tag`または`frames`を使用してください。読み取ったunknownフレームは削除しない限り保持されます。

emsg v0/v1の時刻は整数tick、v1はbigintです。これらは独立した読み書きAPIで、`remux()`が全形式のタグを自動移植するものではありません。Matroskaの既存Chapters/AttachmentsはMatroska同士で引き継げます。

通常MP4同士の再梱包では、元の先頭空編集・media time・表示時間・トラック時計を保持します。低水準Muxerで同じ指定を行う場合は、standardモードで`presentationMediaTimeSeconds`、`presentationStartSeconds`、`presentationDurationSeconds`を一緒に指定し、必要なら`mediaTimescale`を付けます。これは符号化済みサンプルの時間表を保持する指定です。この指定時は、従来のpriming処理による時間表の変更を行いません。MP4で表現できないIETF言語タグは`MP4_LANGUAGE_LOSS`で通知します。

## 3.7: 実トラックに基づく書き出し照会

```ts
const plan = file.checkRemux({ format: 'mp4' });
if (!plan.supported) throw new Error(`${plan.code}: ${plan.reason}`);
console.log(plan.outputFormat, plan.layout, plan.warnings);
await file.remux(sink, { format: 'mp4' });
```

`checkRemux()`はSourceを読まず、呼出側のSinkやonWarningへ通知しません。トラック数・形式・必要な設定の有無・writerの初期設定・保持できない属性を確認します。返り値はsupported=trueならoutputFormat/layout/warnings、falseならcode/reason/warnings。パケット内容、すべての設定バイトの正当性、I/O成功や復号可能性の保証ではありません。検出した属性損失はfileのvalidation設定を尊重します。

`RemuxOptions.mp4Mode`は`'auto' | 'standard' | 'fragmented'`。MP4/M4A/M4Vにだけ指定でき、既定autoは従来writerに対応する組合せをstandard、Opus/FLAC/ALAC/VP9・対応字幕などを分割MP4へ接続します。M4Aは音声だけです。MOV/3GPは従来の対応範囲を維持します。autoは再符号化しません。必要なdecoder configurationや字幕ペイロード形式も一致している必要があります。

MediaTrackは`default?:boolean`, `forced?:boolean`, `alphaMode?:boolean`を公開します。Matroska/WebMのパケットは`alphaData?:Uint8Array`を持つことがあります。映像本体と別のVP8/VP9 alpha側帯データであり、コピー時には両方を引き渡してください。返却バイト列の変更は次回のreadPacketへ影響しません。MP4等が同じ属性を表現できない場合は診断または拒否となります。

## 3.7.1: 表示情報とMatroskaメタデータ

`tracks`は`name?:string`, `title?:string`, `commentary?:boolean`も返し、全体タイトルは`file.title`です。MP4/MOV/fMP4は既定指定・対応字幕のforced・commentary・名前・タイトルを保持します。強制指定の音声・映像はMP4で表現できず拒否します。MKV/WebMへのコピーは名前・default/forced/commentary、全体タイトルとタグを保持します。`matroskaTrackUid?:bigint`は64bitのTrackUIDを正確に保持します。残るトラック・章・Edition・添付ファイルへの対象付きタグも保持します。複数対象の一部が出力から外れる場合、そのTag全体を警告付きで除外し、別トラックや全体タグへ付け替えません。WebMでは章・添付ファイルを保持しないため、それらを対象にするタグも除外します。出力形式で表現できない任意情報は`checkRemux().warnings`と実出力の警告に現れ、既定ではstrictでも変換を続行します。保持を必須にする場合は`open`に`metadataPolicy:'error'`を指定します。すべての形式のメタデータを保持する契約ではありません。

## トラック情報のJSON保存

`JSON.stringify(file.tracks)`はUIDを10進文字列、`codecConfig`を数値のbyte配列として保存します。取得したトラックのUIDは引き続き`bigint`、設定bytesは`Uint8Array`です。返却コピーだけに非列挙の`toJSON`を設け、グローバルや組み込みprototypeは変更しません。

```ts
import { serializeTracks, deserializeTracks } from 'mediaforgejs/metadata';

const json = serializeTracks(file.tracks);
const tracks = deserializeTracks(json);
// tracks[0].matroskaTrackUid: bigint | undefined
// tracks[0].codecConfig: Uint8Array | undefined
```

`deserializeTracks`は`JSON.stringify(file.tracks)`の結果も受け取ります。復元対象はトラックのメタデータで、元のMediaFile・Source・パケット索引を復元するものではありません。スプレッドで複製すると非列挙の`toJSON`は消えるため、その配列には`serializeTracks`を使います。未知の列挙プロパティは通常のJSON規則に従い、任意の文字列や入れ子をBigIntへ変換しません。

両helperの上限は4096トラック、トラックごとのcodecConfigが1 MiB、JSONテキストが16 Mi UTF-16コード単位です。UIDは1〜2^64−1の正規化された10進文字列のみ受け入れ、数値型のUIDは丸めの有無を判断できないため拒否します。不正なスキーマは`FORMAT`です。循環参照や未知のBigInt拡張値は通常のJSON例外になり、利用側のアクセサーや拡張値の`toJSON`が投げた例外はそのまま返します。自然な`JSON.stringify`には配列全体のhelper上限は適用されません。独自の`toJSON`フィールドを含む復元値の再保存にも明示的なhelperを使ってください。

`checkRemux()`は登録されたwriterと実出力の設定検証を共有します。MKVでは小数の表示寸法を正確な比へ変換し、無効な寸法・表示情報・必須設定の欠落を出力前に拒否します。パケット全件、デコーダー、出力先I/O、実プレイヤーの成功はこの同期照会では検証しません。

## 全件検証

5.0では`await file.validateRemux(request, {maxBytes})`を追加しました。実出力と同じパケット処理・writer・finalizeを保存しないSinkで実行します。同期の`checkRemux`は設定照会のままです。推奨の高水準入口は[Workflow](WORKFLOW-JA.md)です。

## 低水準MP4のサンプル読込

`MP4Demuxer.readSample(sample)`は、同じdemuxerで正常に解析した入力が一つに確定する場合に利用できます。解析前は`DEMUX`で拒否します。異なる入力を正常に解析したdemuxerでは、`readSample(input, sample)`へ入力を明示してください。失敗した解析はこの入力の対応付けを変更しません。大きなファイルの通常処理には、入力の寿命を管理するWorkflow/MediaFileを使用します。
