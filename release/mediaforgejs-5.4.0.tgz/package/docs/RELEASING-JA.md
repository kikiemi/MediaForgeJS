# npm配布と公開

## 作成と検証

```sh
npm ci
npm run build
npm run check
npm run release:pack
npm run release:verify
```

`release:pack` は本体と6拡張を `release/` へ梱包し、版・サイズ・SHA-256・SHA-512・ライセンス文書を `manifest.json` に記録します。ProRes の完全な実行時依存は `release/offline/dependencies/`、検証・開発用 TypeScript/Prettier は `release/offline/toolchain/` に分けて配置します。7つの npm 公開パッケージへ依存や検証ツールを内包しません。

外部依存は既存の `release/offline/` 内の原本、または lockfile の tarball URL を `npm pack --offline` で読み、原本の SHA-512 と照合します。初回の原本は通常、事前の `npm ci` で取得されます。キャッシュが不足している作成環境では、接続可能な環境で lockfile の tarball を取得してから再梱包してください。不足した archive を黙って省略することはありません。

`release:verify` は共有キャッシュや開発用 `node_modules` を使わず、空の専用 npm キャッシュから本体・拡張・依存をローカル tarball だけでインストールします。別の空の環境へ同梱コンパイラーも展開し、公開された全型付き entrypoint を NodeNext/strict で確認します。npm と実行時の Node ネットワーク API を遮断して、AAC・PCM・M4A、Workflow、実 ProRes の符号化/復号・変換、RAW 復号を実行します。スクリプトによるインストールは不要です。

新規のソース ZIP では `node release/offline/install.mjs . --development` で開発用依存もオフライン展開できます。ビルド済み tarball を含むソース ZIP は、開発用依存がなくても `node scripts/release.mjs verify` で検証できます。オフライン環境への持ち込み、独立インストーラー、ブラウザー用のローカル確認サーバーは [オフライン利用](OFFLINE-JA.md) を参照してください。

ソース変更後は再ビルドと検証を行ってから梱包します。テストは生成素材を使い、標準の Node 検証に FFmpeg や外部メディアのダウンロードは不要です。

## レジストリへの公開

公開は未実施です。公開権限のある環境で認証し、検証済みの本体と6拡張だけを、本体から順に公開します。`release/offline/` は持ち込み用の配布物で、当プロジェクトの名前で npm に再公開する対象ではありません。

```sh
npm whoami
npm publish ./release/mediaforgejs-5.4.0.tgz --access public
npm publish ./release/mediaforgejs-audio-5.4.0.tgz --access public
npm publish ./release/mediaforgejs-drm-5.4.0.tgz --access public
npm publish ./release/mediaforgejs-streaming-5.4.0.tgz --access public
npm publish ./release/mediaforgejs-ffmpeg-5.4.0.tgz --access public
npm publish ./release/mediaforgejs-prores-5.4.0.tgz --access public
npm publish ./release/mediaforgejs-prores-raw-5.4.0.tgz --access public
```

公開後は `npm install mediaforgejs` または必要な拡張名でインストールできます。通常の ProRes 拡張だけが `turbores` と `prores-wasm-encoder` を実行時依存に持ちます。本体のみのインストールは ProRes コーデックを追加しません。MPL/LGPL のライセンスとソース提供条件は各拡張と依存パッケージの LICENSE・NOTICE を参照してください。

## 実ブラウザーCI

Chrome・Firefox・Safari の実行用ワークフローとハーネスは [ブラウザーCI](BROWSER-CI-JA.md) を参照してください。Node のリリース検証、localhost サーバーの準備、実ブラウザーでの再生、認可された商用 DRM サービスでの確認は別の検証項目です。`release:verify` はブラウザー未実行を明示します。
