# 5.0への移行

Workflowの`check`が非同期の実処理検証になり、進捗を1種類へ統一したため、メジャーバージョンを更新しました。新規の検査・再梱包・音声変換は`mediaforgejs/workflow`を推奨します。

| 4.0 | 5.0 |
| --- | --- |
| `job.check(request)`で設定だけを照会 | `job.probe(request)` |
| 実出力できるか事前に検査 | `await job.check(request, {maxBytes})` |
| remuxの進捗`{packets, packetBytes}`とaudioの`(fraction, message)` | 全Workflow操作で`({fraction, message, packets, packetBytes})` |
| 通常Workflowの既定出力はPCMのみ | 組み込みの音声エンコーダーとAAC-LC/MPEG I/IIデコーダーを登録 |
| 小さいPCM専用Workflow | `workflow/core`と`workflow/audio-pcm`を使用 |
| AVIの16 bit PCMが汎用`pcm` | AVIでは格納方式が明確な`pcm-s16le`。MKVへのコピーも可能 |
| MP4の既定指定／名前／タイトルが未読 | `default`、`name`、`title`とコンテナ`title`を公開・保持 |

```ts
const request = { operation: 'remux', format: 'mkv' } as const;
const quick = job.probe(request);
const verified = await job.check(request, { maxBytes: 64 * 1024 * 1024 });
```

`check`と出力を両方呼ぶと処理は2回です。事前に結果が不要なら直接出力できます。メモリ保持を抑える検証用Sinkを使いますが、writer・コーデック内部の作業領域は必要です。未来のI/O失敗やブラウザーの再生成功を保証するものではありません。

Engineの`checkRemux`は従来通り同期の設定照会です。全件検証の`validateRemux(request, {maxBytes})`を追加しました。Converter/Pipelineのメソッド名・進捗形式・`strict`の意味は変更していません。従来PipelineはWorkflowやFFmpegを読み込みません。

MP4の`default`は`tkhd`のTrack_enabledを保持します。複数の有効トラックから実際に何を選ぶかはプレイヤーに依存します。`forced:true`は対応字幕の役割として保持します。一般の音声・映像に強制表示を表す同等の標準フィールドはないため、MP4出力では拒否します。`forced:false`や未指定は、再読込時にfalseへ正規化されます。

名前とタイトルは独立した文字列で、日本語・空文字も保持します。MOVへのProResコピーは`apco/apcs/apcn/apch/ap4h/ap4x`に対応します。MP4へProResを偽装したり、新たにProResを復号・符号化する機能は追加していません。

本体と4拡張のバージョンをすべて5.0.0へ更新してください。旧FlowCast名は引き続き明示的な`compat/flowcast`入口だけから利用します。
