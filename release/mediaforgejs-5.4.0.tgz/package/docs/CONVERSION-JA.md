# 従来の変換API

`MediaForgeConverter`、`Pipeline`、画像・音声エンコーダー、Source/Sink、既存demuxer/muxerは維持しています。3.0のパケットAPIは再圧縮しない処理のための追加レイヤーです。

```ts
import { MediaForgeConverter, convertBatch } from 'mediaforgejs';

export async function convert(input: Blob): Promise<Blob> {
    const converter = new MediaForgeConverter({
        outputFormat: 'mp3', audioBitrate: 192, audioSampleRate: 48000,
    });
    return converter.convert(input);
}

export async function resize(input: Blob): Promise<Blob> {
    return new MediaForgeConverter({
        outputFormat: 'png', width: 1280, height: 720,
        imageFit: 'inside', imageResize: 'lanczos3',
    }).convert(input);
}

export async function batch(inputs: Blob[]) {
    return convertBatch(inputs, { outputFormat: 'flac' }, { concurrency: 2 });
}
```

ビットレートはkbps、画像の寸法はピクセルです。`imageFit:'inside'`は縦横比を保ち、`'scale-down'`は拡大を防ぎます。リサイズ方式は`nearest`、`bilinear`、`lanczos3`。画像復号や描画が必要な経路ではブラウザーのCanvas・ImageBitmapなどが必要です。

音声の自己実装エンコーダーにはAAC-LC、MP3、MP2、FLAC、PCM出力があります。MP1/MP2の対応プロファイルは内蔵デコーダーを使います。MP3復号、動画の再圧縮、一部の音声復号はWebCodecsなどホストの機能に依存します。コーデックが識別できることと、復号・符号化できることは別です。HE-AACなどを要求してAAC-LCに偽装することはありません。

低水準では`encodeAacLc`、`encodeMP3`、`encodeMP2`、`encodeFlac`、`encodeReplayablePcmToSink`などを利用できます。PNG/JPEG/BMP/TIFF/ICO、GIF/APNGの出力APIも維持しています。正確な引数・公開設定は`dist/index.d.ts`から参照できる各宣言ファイルが定義です。

大きな出力は`MemorySink`やBlobへ全体保持せず、適切なSinkへの書き込みと`drain()`を使用してください。`ReadableStreamSink`は消費側を並行して読み、消費前に出力の完了だけを待たないでください。キャッシュやストリームの上限は処理全体のメモリー上限とは異なります。

作成したObject URLは使用後に`URL.revokeObjectURL`で解放します。ファイルやストリームの所有権、中止時の後始末は新旧APIでも維持してください。暗号化メディアや、ライブラリ／実行環境に実装のないコーデックの変換はできません。

`MediaForgeConverter`と`Pipeline`の設定にも`metadataPolicy:'warn'|'error'`を指定できます。既定は警告で続行し、`'error'`は検出したMatroskaの任意属性・タグ、トラック指定、言語などの損失を出力前に`FORMAT`で拒否します。通常出力・Sink・ReadableStream、Converterから内部Pipelineへの委譲、選択構成でも同じ方針です。警告は既存のloggerへ送ります。構造の読み込みは従来の互換処理を維持します。

同形式で変換指定がない場合はメタデータを含む元bytesをコピーします。ただし、検査時に不正な任意属性を検出し、保持必須を指定している場合は拒否します。全形式のすべての付加情報を保持する保証ではありません。保持確認と音声処理は、同一変換の解析済み結果を共有します。保持必須の動画→画像変換は、ブラウザーへ渡す前に既知の情報損失を確認するため追加の解析を行います。

## PCMの通常変換とストリーム出力

AIFF/AIFC・AU・CAFの対応PCMとAVI PCM16も、DOMやWebCodecsなしで音声変換へ渡せます。パケットをFloat32の小さい作業単位へ直接復号し、再サンプリング・チャンネル変換・符号化へ渡します。AIFF/AU/CAFはmono/stereoの対応部分集合です。PCMパケットの間に隙間・重複や未対応の編集がある場合、連続音声として詰めて出力せず拒否します。

```ts
import { MediaForgeConverter, type Sink } from 'mediaforgejs';

export async function convertPcm(input: Blob, sink: Sink): Promise<void> {
    const converter = new MediaForgeConverter({
        outputFormat: 'caf', audioSampleRate: 48000, audioChannels: 2,
    });
    await converter.convertToSink(input, sink);
}
```

`outputFormat:'aiff'|'au'|'caf'`で復号・再符号化する場合はPCM16を出力します。同じ形式で変換設定がない場合は既存のパススルーを使い、元のサンプル精度を維持します。AIFF/AUはbig-endian、CAFはlittle-endianです。通常の復号・再符号化はFloat32とPCM16への量子化を伴います。元の整数24/32bit・float64などの全ビットを維持する目的には、API-JA.mdの`MediaFile.remux()`を使います。指定のない多チャンネル入力をAIFF/AU/CAFへ黙ってダウンミックスせず、必要なら`audioChannels:1|2`を指定します。

`encodeReplayablePcm()`と`encodeReplayablePcmToSink()`でも`aiff`・`au`・`caf`を指定できます。PCM出力はpatch可能なSinkなら1回、前方書き込みだけのSinkならフレーム数を数えて2回再生します。`estimatedFrames`は推定値で、ヘッダーは実測値から作ります。再生ごとに長さが変われば拒否し、`drain()`で出力の進行を待ちます。Blob結果は完成した出力全体を保持します。

## アニメーションの再生回数

GIFから読み取る繰り返し回数を、変換内部ではAPNGと同じ総再生回数へ変換します。拡縮・GIF/APNG間変換で有限回数を維持します。`AnimatedGifEncoder.fromPlayCount(width, height, playCount, options?)`は0が無限、1が1回、2〜65536がその総再生回数です。65536を超える有限APNGをGIFへ変換する場合は表現不能として拒否します。既存の`AnimatedGifEncoder`コンストラクターの数値規則は互換性のため維持します。静止画像への`fps`指定は反映できないため`FORMAT`で拒否します。

## 3.7: 画像の透過

BMP/TIFFは透明・半透明の画素を保持します。BMPは透明があるときV5 BGRA、TIFFはunassociated alphaを使用し、完全不透明な入力では従来のRGB形式を維持します。

JPEGは透明画素があるとENCODE、GIFは1〜254の半透明alphaがあるとENCODEになります。GIFのalpha=0/255は対応。透明を破棄する必要がある場合は、呼出側で背景色を選んで合成してください。例えばCanvasのfillRectで不透明背景を塗り、その上へdrawImageしてからエンコードします。画像リサイズが半透明の境界を作った場合も同じ規則です。

## 処理部品を選ぶ

`converter/core`と`pipeline/core`は第2引数に形式と必要な処理部品を渡します。登録はインスタンス単位で、足りない形式・処理・コーデックは`FORMAT`で通知します。従来の`converter`・`pipeline`とルート入口は既定の部品一式を登録します。

3.9.0の従来`pipeline`入口は、Converter専用の画像変換・音声符号化の実装を読み込みません。既定Pipelineの構成だけを再利用する場合は`conversion/pipeline-defaults`の`defaultPipelineOptions`、Converterを含む一式は`conversion/defaults`の`defaultConversionOptions`を使えます。依存を最小にする場合は引き続き`core`入口へ必要な形式・処理を渡してください。

```ts
import { MediaForgeConverter } from 'mediaforgejs/converter/core';
import { audio } from 'mediaforgejs/engine/formats/audio';
import { createAudioConversion } from 'mediaforgejs/conversion/audio';
import { pcmAudio } from 'mediaforgejs/conversion/audio-pcm';
import { flacAudio } from 'mediaforgejs/conversion/audio-flac';

const converter = new MediaForgeConverter(
    { outputFormat: 'flac', audioSampleRate: 24000 },
    { formats: [audio], audio: createAudioConversion([pcmAudio, flacAudio]) },
);
export const convert = (input: Blob) => converter.convert(input);
```

この組み合わせは画像・映像処理、AAC/MP3エンコーダー、MP4/Matroskaの読み書き実装を読み込みません。入力検出やPCM処理など共有コードは含みます。`convertToSink`・`convertToReadableStream`も同じ組み合わせを使います。

```ts
import { Pipeline } from 'mediaforgejs/pipeline/core';
import { mp4 } from 'mediaforgejs/engine/formats/mp4';
import { matroska } from 'mediaforgejs/engine/formats/matroska';

const pipeline = new Pipeline({
    outputFormat: 'mkv', videoCodec: '', audioCodec: '',
    width: 0, height: 0, fps: 0, videoBitrate: 0, audioBitrate: 0,
    audioSampleRate: 0, audioChannels: 0,
}, { formats: [mp4, matroska] });
export const remux = (input: Blob) => pipeline.run(input);
```

コピーに音声・映像エンコーダーの登録は不要です。再符号化には`conversion/pipeline-audio`の`pipelineAudio`、`conversion/pipeline-video`の`pipelineVideo`など必要な段階を追加します。画像変換は`conversion/image`の`imageConversion`を`image`へ指定します。Converterの音声ファミリーは`pcmAudio`・`flacAudio`・`aacAudio`・`mp3Audio`・`mp2Audio`・`opusAudio`・`vorbisAudio`（Vorbisは復号のみ）、M4A出力は`m4aAudio`を選べます。ブラウザーAPIに依存する処理は、その実行環境の対応も必要です。

## TSへのコピー（5.1以降）

Pipeline/ConverterのMP4・M4A・AACなどからTSへのコピーは、Blob出力とSink出力で複数音声を保持します。映像と全音声を復号時刻順に書き出し、追加音声のペイロードを先に全量保持しません。

```ts
const converter = new MediaForgeConverter({ outputFormat: 'ts' });
const output = await converter.convert(input);
await converter.convertToSink(input, sink);
```

複数音声があり再符号化を伴う場合は、`audioTrackIndex`で処理する音声を選んでください。未選択では出力前に拒否し、暗黙に音声を落としません。AVI H.264とProRes MOV/MKVの対応するコピー経路もWebCodecsを必要としません。新規コードでは`MediaWorkflow`を推奨します。
