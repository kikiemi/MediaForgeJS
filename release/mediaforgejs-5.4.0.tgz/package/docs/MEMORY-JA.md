# 大きな入力とメモリ使用量

5.4.0は全経路のconstant-memoryを保証しません。入力のバイト数だけでなく、サンプル数・トラック数・索引の配置・同時処理数・画素数が影響します。100GBの疎なSourceを開けることと、100GBの全パケットを処理して一定のメモリ量に収まることは異なります。

| 経路 | 保持するデータ | 大きなファイルでの選択 |
| --- | --- | --- |
| `FileSource` / `BlobSource` | 読み取り範囲とキャッシュ | 全入力を`readFile`や`arrayBuffer()`へ展開せず渡す |
| `BufferSource` | 入力全体。既定では入力のコピーも保持 | 既にメモリにある小さな入力に使う |
| `StreamSource` / `nodeReadableSource` | 指定上限まで入力全体 | 全量保持する入口。巨大入力にはファイルのSourceを使う |
| Engine / Workflowのopen | 形式ごとの索引 | `maxIndexBytes`・`maxSamples`・`cacheBytes`を指定する |
| 標準MP4/MOVの出力 | サンプル表。seekできないSinkでは圧縮パケットも保持 | `FileSink`等のseek可能なSinkへ出力する |
| fMP4 / 分割出力 | 断片のパケットと索引 | 対応する構成では`maxBufferedBytes`・`maxBufferedSamples`を指定する。入力索引は別途保持する |
| `toBlob` / `MemorySink` | 出力全体 | 巨大出力には`write`かReadableStreamを使う |
| ProResの符号化・復号 | 画素数・内部WASM容量・キュー内フレーム | コーデックを再利用し、返されたframeを閉じ、不要な参照を外す |
| `batch` | 並行ジョブの資源と完成した全Blob | 巨大出力はファイルへ逐次`write`する |

上限は無限の入力を処理可能にする仕組みではありません。索引上限を超える入力は`OOM`で拒否します。利用者のSource・Sinkの実装、ホストのコーデック、利用者が保持するバッファまで含む総RSSの上限ではありません。

## 5.4.0の変更

classic MP4の可変サンプルサイズを8/16/32bitの最小幅で保持し、連続するデータの位置は疎なチェックポイントから復元します。順次読込にはカーソルを使い、ランダム読込は1区間内の加算で復元します。異なる順序で呼んでも位置・時刻は変わりません。サイズが一定の入力は算術で位置を求めます。全サンプルが離れた配置などでは密な索引を選びます。

標準MP4の出力表も数値配列と時刻の連続区間にまとめ、パケットごとのJavaScriptオブジェクトやfinalize時の一時配列を減らします。それでもサンプル数に比例する表は残ります。

`maxIndexBytes`はcompact MP4の内部moov読込領域も対象にします。以前より早く上限に達する場合は、実際のメタデータに必要な予算を設定してください。Sourceが内部に持つ読み取りキャッシュは別です。

## ファイルへ出力する

```ts
import { MediaWorkflow } from 'mediaforgejs/workflow';
import { FileSource, FileSink } from 'mediaforgejs/runtime/node';

const workflow = new MediaWorkflow();
const source = await FileSource.open('input.mp4');
try {
    const sink = await FileSink.open('output.ts');
    try {
        await workflow.write(source, sink, { operation: 'remux', format: 'ts' }, {
            open: { maxIndexBytes: 64 * 1024 * 1024, cacheBytes: 4 * 1024 * 1024 },
        });
    } catch (error) {
        await sink.abort(error);
        throw error;
    }
} finally {
    await source.close();
}
```

これは対応するトラック構成のコピー例です。出力先に合わせたトラック選択は[Workflow](WORKFLOW-JA.md)を参照してください。`FileSink.open()`は指定した出力を切り詰めます。入力と異なるパスを使います。

`check`と`write`は既定の出力サイズ上限を設けません。`maxBytes`を指定すると同じ上限を適用します。`toBlob`は既定で256 MiBまでです。`check`自体も全処理を走らせるため、出力前に毎回呼ぶ必要はありません。
