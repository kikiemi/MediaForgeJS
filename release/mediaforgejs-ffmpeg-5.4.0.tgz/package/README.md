# mediaforgejs-ffmpeg

MediaForgeJS 5 の ffmpeg 機能を選択する ESM 入口です。本体は peer dependency として共有し、実装を重複して同梱しません。ディスク上の本体を分割するパッケージではありません。

未公開の配布版では、同梱した本体と拡張の tarball を一緒にインストールします。公開後は `npm install mediaforgejs-ffmpeg` で利用できます。

`import * as api from 'mediaforgejs-ffmpeg';`

FFmpeg/ffprobe は利用側の導入が必要です。他の拡張と本体はこのパッケージを読み込みません。
