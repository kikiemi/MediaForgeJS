# mediaforgejs-streaming

MediaForgeJS 5 の streaming 機能を選択する ESM 入口です。本体は peer dependency として共有し、実装を重複して同梱しません。ディスク上の本体を分割するパッケージではありません。

未公開の配布版では、同梱した本体と拡張の tarball を一緒にインストールします。公開後は `npm install mediaforgejs-streaming` で利用できます。

`import * as api from 'mediaforgejs-streaming';`

実行時に FFmpeg は必要ありません。対応形式と環境条件は本体の公開資料を参照してください。
